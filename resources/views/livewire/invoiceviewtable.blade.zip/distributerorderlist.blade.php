<div>
    <div class="container mt-3">
        <div class="row">
        <div class="card">
        <div class="card-header">
            <div class="row mt-2">
                <div class="col-md-8">
                <span class="card-title">Order  List</span> &nbsp;&nbsp;

                <button onclick="exportTableToExcel('myTable', 'InvoicesData')" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Excel</button>
                <button onclick="downloadPDF()" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">PDF</button>
             
             
            </div>

                <div class="col-md-4">
                  <div class="row justify-content-end">
                        <div class=" d-flex align-items-center">
                            <span for="search" class="form-label me-2">Search:</span>
                            <input type="text" class="form-control" name="search" id="search" placeholder="Search table data...">
                    
                    </div>
                </div>
                </div>
            </div>
            </div>
            
        <div class="card-body">
        <div class="table-responsive">
        <table class="table mb-0" >
        <thead class="thead-light">
        
            <tr>
                <th>Register ID</th>
                <th>Username</th>
                <th>Contact No</th>
                <th>Region</th>
                <th>Product Name</th>
                <th>Inventory</th>
        </tr>
        </thead>
        <tbody>
            
            @foreach ($getroleid as $tabdata)
            @foreach ($junctiontab->where('uid', $tabdata->id) as $item)
                @php
                    // Find the product data matching the `pid` in the junction table
                    $product = $products->firstWhere('id', $item->pid);
                @endphp
                @if ($product)
                    <tr>
                        <th scope="row">{{ $tabdata->registerid }}</th>
                        <td>{{ $tabdata->username }}</td>
                        <td>{{ $tabdata->contactno }}</td>
                        <td>{{ $tabdata->region }}</td>
                        <td>{{ $product->productname }}</td>
                        <td>{{ $item->inventery }}</td>
                    </tr>
                @endif
            @endforeach
        @endforeach
        </tbody>
        </table>
        </div>
        </div>
        </div>
        </div>

 
        
    </div>