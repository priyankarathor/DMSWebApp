<div>
    <style>
        * {
            font-family: "Lato", sans-serif;
            font-weight: <weight>;
            font-style: normal;
            font-size: 10px;
        }
    </style>
    <div class="page-wrapper">

        <div class="container-fluid mt-4" style="padding: 60px;">
            <div class="row">
                <div class="col-lg-12 mx-auto">
                    <div class="card">
                        <div class="card-body invoice-head">
                            <div class="row">
                                <meta charset="UTF-8">
                                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                <title>Invoice</title>
                                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                                    rel="stylesheet"
                                    integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
                                    crossorigin="anonymous">
                                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
                                    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
                                </script>
                                <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
                                    integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
                                </script>
                                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
                                    integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous">
                                </script>

                                <body class="border border-2 m-5">
                                    <div class="container">
                                        <div class="invoice-box">
                                            <div class="row">

                                                <header>
                                                    <div class="container p-2 border-bottom border-3 border-dark">
                                                        <div class="row">
                                                            <div class="col-6">
                                                                <img src="{{ asset('image/vmlogo.png') }}"
                                                                    alt="logo-small"
                                                                    style="width: 35%; height:auto; text-align: center !important;"
                                                                    class="mb-1 mt-1">
                                                            </div>
                                                            <div class="col-6 ps-3">
                                                                <ul class="fs-6">
                                                                    <li>
                                                                        <b>Phone : </b>+91 9829361615
                                                                    </li>
                                                                    <li>
                                                                        <b>Email : </b>info@vandemileagerlubricant.com
                                                                    </li>
                                                                    <li>
                                                                        <b>GST NO.</b> : 08AHHPC4356M1Z4
                                                                    </li>
                                                                    <li>
                                                                        Company corporate office Near by TTC
                                                                        Industrial Area (MIDC) North Central Road
                                                                        Navi Mumbai - 400701 Maharashtra
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </header>

                                                <section>
                                                    <div class="container-fluid px-3 pt-3">
                                                        <div class="row pb-0">
                                                            <div class="col-12 text-center">
                                                                <h5 class="display-4 fw-bold">
                                                                    GST INVOICE</h5>
                                                            </div>
                                                            <div class="col-10 pb-4 ps-2">
                                                                <span>
                                                                    <b class="fs-5"> Invoice No. : </b>
                                                                    {{ $productdata->invoiceno }}
                                                                </span>
                                                            </div>

                                                            <div class="col-2 pb-4 ps-0">
                                                                <span>
                                                                    <b class="fs-5"> Date : </b>
                                                                    {{ $productdata->invoicedate }}
                                                                </span>
                                                            </div>
                                                            <div class="col-5 px-2 mt-3">
                                                                <h5><u class="fw-bolder fs-5">SUPPLIER TO</u></h5>
                                                                <span>
                                                                    <b class="fs-5">Consignee : </b>
                                                                    {{ $productdata->username }}
                                                                </span><br>
                                                                <span>
                                                                    {{ $productdata->address }}
                                                                </span><br>
                                                                <span>
                                                                    <b class="fs-5">{{ $productdata->userrole }} :
                                                                    </b>{{ $productdata->username }}
                                                                </span><br>
                                                                <span>
                                                                    {{ $productdata->address }}
                                                                </span>
                                                            </div>

                                                            <div class="col ps-2 mt-3">
                                                                <h5><u class="fw-bolder fs-5">INVOICE TO</u></h5>
                                                                <h6>{{ $productdata->framname }}</h6>

                                                                <span>
                                                                    <b class="fs-5">Ph :
                                                                    </b>+91{{ $productdata->contactno }}
                                                                </span><br>
                                                                <span>
                                                                    <b class="fs-5">Em :
                                                                    </b>{{ $productdata->email }}
                                                                </span><br>
                                                                <span>
                                                                    <b class="fs-5">GST No. : </b>
                                                                    {{ $productdata->gstnumber }}
                                                                </span><br>
                                                                <span>
                                                                    <b class="fs-5">Udyam Card No. :
                                                                    </b>{{ $productdata->udyamno }}
                                                                </span>
                                                            </div>
                                                            <div class="col ps-2 mt-3">
                                                                <span>
                                                                    <b class="fs-5">Buyers Order No. :
                                                                    </b>{{ $productdata->id }}
                                                                </span><br>
                                                                {{-- <span>
                                                                        <b class="fs-5">Other Reference : </b>543 Kg
                                                                    </span><br> --}}
                                                                <span>
                                                                    <b class="fs-5">Destination :
                                                                    </b>{{ $productdata->region }}
                                                                </span><br>
                                                                <span>
                                                                    <b class="fs-5">Bill of Loading/R R No. :
                                                                    </b>{{ $productdata->id }}
                                                                </span><br>
                                                                <b class="fs-5">Dispatch Through</b>
                                                                <span>{{ $productdata->drivercompany }}</span>
                                                                <br /><span>
                                                                    <b class="fs-5">Contact Person : </b>
                                                                    {{ $productdata->drivername }}
                                                                </span>
                                                                <br />
                                                                <span>
                                                                    <b class="fs-5"> Vehicle No.
                                                                        : </b>{{ $productdata->vehicleno }}
                                                                </span><br />
                                                                <span>
                                                                    <b class="fs-5"> Contact No. : </b>
                                                                    91+{{ $productdata->vehicleno }}
                                                                </span>
                                                            </div>
                                                        </div>
                                                        <div class="row py-2">
                                                            <div class="col-12">
                                                                <table class="table">
                                                                    <thead>
                                                                        <tr class="text-center">
                                                                            <th scope="col"
                                                                                class="col-1 text-white fs-5 ps-2 py-3 pe-0 border-right border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                Sr No.</th>

                                                                            <th scope="col"
                                                                                class="col-4 text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(116, 201, 50)">
                                                                                Item Description</th>

                                                                            <th scope="col"
                                                                                class="text-white fs-5 px-2 py-3 border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                HSN</th>
                                                                            <th scope="col"
                                                                                class="text-white fs-5 px-2 py-3 border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                GST RATE%</th>
                                                                            <th scope="col"
                                                                                class="text-white fs-5 px-2 py-3  border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                QNTY</th>
                                                                            <th scope="col"
                                                                                class="text-white fs-5 px-2 py-3 border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                RATES</th>
                                                                            <th scope="col"
                                                                                class="text-white fs-5 px-2 py-3 border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                BOX / BKT</th>
                                                                            <th scope="col"
                                                                                class="text-white fs-5 px-2 py-3 border-right border-white border-1 rounded-0"
                                                                                style="background-color:rgb(7, 45, 93)">
                                                                                Total</th>
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody>
                                                                        @php
                                                                            // Check if productdata contains values before exploding
                                                                            $productNames = $productdata->productname
                                                                                ? explode(
                                                                                    ',',
                                                                                    $productdata->productname,
                                                                                )
                                                                                : [];
                                                                            $hsncode = $productdata->hsnno
                                                                                ? explode(',', $productdata->hsnno)
                                                                                : [];
                                                                            $Productqty = $productdata->productquantity
                                                                                ? explode(
                                                                                    ',',
                                                                                    $productdata->productquantity,
                                                                                )
                                                                                : [];
                                                                            $amounts = $productdata->amount
                                                                                ? explode(',', $productdata->amount)
                                                                                : [];
                                                                            $productBulks = $productdata->productbulk
                                                                                ? explode(
                                                                                    ',',
                                                                                    $productdata->productbulk,
                                                                                )
                                                                                : [];
                                                                            $totalAmounts = $productdata->totalamount
                                                                                ? explode(
                                                                                    ',',
                                                                                    $productdata->totalamount,
                                                                                )
                                                                                : [];
                                                                        @endphp

                                                                        @foreach ($productNames as $index => $productName)
                                                                            <tr class="text-center">

                                                                                <td>{{ $index + 1 }}</td>
                                                                                <td scope="row"
                                                                                    class="ps-2 pt-3 fs-5">
                                                                                    <b>{{ $productName }}</b>
                                                                                </td>
                                                                                <td class="ps-2 pt-4" scope="row"
                                                                                    style="background-color:rgb(241, 241, 241)">
                                                                                    {{ $hsncode[$index] ?? '' }}
                                                                                </td>
                                                                                <td class="ps-2 pt-4"
                                                                                    style="background-color:rgb(241, 241, 241)">
                                                                                    18 %</td>
                                                                                <td class="ps-2 pt-4" scope="row"
                                                                                    style="background-color:rgb(241, 241, 241)">
                                                                                    {{ $Productqty[$index] ?? '' }}
                                                                                </td>
                                                                                <td class="ps-2 pt-4"
                                                                                    style="background-color:rgb(241, 241, 241)">
                                                                                    {{ $totalAmounts[$index] ?? '' }}
                                                                                </td>

                                                                                <td class="ps-2 pt-4 "
                                                                                    style="background-color:rgb(241, 241, 241)">
                                                                                    {{ $productBulks[$index] ?? '' }}
                                                                                </td>
                                                                                <td class="ps-2 pt-4" scope="row"
                                                                                    style="background-color:rgb(241, 241, 241)">
                                                                                    {{ $amounts[$index] ?? '' }}
                                                                                </td>
                                                                            </tr>
                                                                        @endforeach
                                                                        @php
                                                                        // Explode the comma-separated amount values into an array
                                                                        $totalAmountsArray = explode(',', $productdata->amount);
                                                                        
                                                                        // Calculate the sum of the total amount array
                                                                        $totalDue = array_sum($totalAmountsArray);
                                                                        
                                                                        // Calculate CGST and SGST
                                                                        $cgst = $totalDue * 0.09; // 9% of total due
                                                                        $sgst = $totalDue * 0.09; // 9% of total due
                                                                        $igst = $totalDue * 0.18; // 18% on total due (if applicable)
                                                                        
                                                                        // Calculate Total After Tax
                                                                        $totalAfterTax = $totalDue + $cgst + $sgst; // Add CGST and SGST to total due
                                                                        
                                                                        // Apply discount to Total After Tax
                                                                        $discountedTotal = $totalAfterTax - ($totalAfterTax * ($productdata->discount / 100));
                                                                        
                                                                        // Round-off calculations
                                                                        $roundedTotal = round($discountedTotal); // Rounded grand total
                                                                        $roundOffValue = $discountedTotal - $roundedTotal; // Round off value
                                                                    @endphp
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>Total Amount</span>:
                                                                            <span>{{ number_format($totalDue, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>CGST (9%)</span>:
                                                                            <span>{{ number_format($cgst, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>SGST (9%)</span>:
                                                                            <span>{{ number_format($sgst, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>Total After Tax</span>:
                                                                            <span>{{ number_format($totalAfterTax, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>Discount</span>:
                                                                            <span>{{ $productdata->discount }} %</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>Discounted Total</span>:
                                                                            <span>{{ number_format($discountedTotal, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>Round Off</span>:
                                                                            <span>{{ number_format($roundOffValue, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    <tr class="text-center">
                                                                        <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                                                            <span>Grand Total</span>:
                                                                            <span>{{ number_format($roundedTotal, 2) }}</span>
                                                                        </td>
                                                                    </tr>
                                                                    
                                                                    
                                                                        <tr>
                                                                            <td style="border:none" class="pt-3"
                                                                                colspan="2">
                                                                                <h4 class="ps-2 fw-bold"
                                                                                    style="color:rgb(7, 45, 93)">Thank
                                                                                    you
                                                                                    for your business</h4>
                                                                                <h5 class="ps-4 fw-bold pt-3">Terms &
                                                                                    conditions
                                                                                </h5>
                                                                            </td>
                                                                            <td colspan="12"
                                                                                class="text-center p-0 align-top">
                                                                                <div class="p-2"
                                                                                    style="background-color:rgb(7, 45, 93);color:rgb(116, 201, 50)">
                                                                                    <span class="fs-2 fw-bold">GRAND
                                                                                        TOTAL</span>
                                                                                    <span class="fs-2 fw-bold"> :
                                                                                    </span>
                                                                                    <span class="fs-2 fw-bold">
                                                                                        {{-- {{ floor($totalDue * 0.18 + $totalDue) }} --}}

                                                                                        {{ number_format($roundedTotal, 2) }}
                                                                                    </span>
                                                                                </div>
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>

                                                            
                                                               
                                                            </div>
                                                        </div>
                                                    </div>
                                                </section>

                                                <footer>
                                                    <div class="container-fluid p-4 border-top border-dark border-2">
                                                        <div class="row">
                                                            <div class="col-4 pt-3">
                                                                <h3 class="fs-4 fw-bold"><u>PAYMENT METHODS</u></h3>
                                                                <span class="fw-bold">Paypal :</span>
                                                                <span>info@bizzgrow@company.email.com</span><br>
                                                                <span class="fw-bold">Payment :</span>
                                                                <span>Visa Master card we accept cheque</span>
                                                            </div>
                                                            <div class="col-4">

                                                            </div>
                                                            <div class="col-4">
                                                                <u class="fs-3"><i>Mic Johnson</i></u>
                                                                <h3 class="fw-bold">Michale Johnson</h3>
                                                                <span>
                                                                    Managing Director , Company Name INC.
                                                                </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </footer>


                                            </div>

                                        </div>
                                        <div class="container">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <button id="download-btn"
                                                        class="btn btn-outline-success mt-5 mb-5"
                                                        style="float:right;">Download PDF</button>
                                                </div>
                                            </div>
                                        </div>

                                        <script>
                                            document.getElementById("download-btn").addEventListener("click", function() {
                                                var element = document.querySelector(".invoice-box");
                                                html2pdf(element, {
                                                    margin: 10,
                                                    filename: 'Concentics Pvt Ltd.pdf',
                                                    image: {
                                                        type: 'jpeg',
                                                        quality: 0.98
                                                    },
                                                    html2canvas: {
                                                        scale: 2
                                                    },
                                                    jsPDF: {
                                                        unit: 'mm',
                                                        format: 'a4',
                                                        orientation: 'portrait'
                                                    }
                                                });
                                            });
                                        </script>
                                        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
                                </body>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
