<div>
    <div class="container mt-3">
        <div class="row">
        <div class="card">
        <div class="card-header">
            <div class="row mt-2">
                <div class="col-md-8">
                <span class="card-title">Order  List</span> &nbsp;&nbsp;

                <button onclick="exportTableToExcel('myTable', 'InvoicesData')" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Excel</button>
                <button onclick="downloadPDF()" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">PDF</button>
             
               <a href="#"> <button  class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">All</button></a>
                 
            </div>

                <div class="col-md-4">
                  <div class="row justify-content-end">
                        <div class=" d-flex align-items-center">
                            <span for="search" class="form-label me-2">Search:</span>
                            <input type="text" class="form-control" name="search" id="search" placeholder="Search table data...">
                    
                    </div>
                </div>
                </div>
            </div>
            </div>
            
        <div class="card-body">
        <div class="table-responsive">
        <table class="table mb-0" id="myTable">
        <thead class="thead-light">
            <th>User Register Id</th>
            <th>User Name</th>
            <th>User Contact</th>
            <th>User Role</th>
            <th>Access</th>
        </tr>
        </thead>
        <tbody>
            @php
            function fetchHierarchy($tab, $parentId) {
                $result = [];
                foreach ($tab as $user) {
                    if ($user->assignid == $parentId) {
                        $result[] = $user;
                        $result = array_merge($result, fetchHierarchy($tab, $user->id));
                    }
                }
                return $result;
            }
            @endphp
            
            @foreach ($users as $usertab)
                @foreach ($tab as $tables)
                
                    @if($usertab->ragisternum == $tables->id)
                        <tr style="display:none;">
                            <td style="display:none;">{{ $tables->registerid }}</td>
                            <td style="display:none;">{{ $tables->username }}</td>
                            <td style="display:none;">{{ $tables->roleid }}</td>
                        </tr>
            
                        @php
                            $hierarchy = fetchHierarchy($tab, $tables->id);
                        @endphp
            
                        @foreach ($hierarchy as $child)
                            <tr>
                                <td>{{ $child->registerid }}</td>
                                <td>{{ $child->username }}</td>
                                <td>{{ $child->contactno }}</td>
                                <td>{{ $child->roleid }}</td>
            
                              
                                @foreach ($orderdata as $item)
                                @if($item->userid == $child->id)
                                <td><a href="{{url('/orderproduct/'.$item->id)}}"><p class="btn btn-success">Product</p></a></td>
                                @endif
                                @endforeach
                             
                            </tr>
                        @endforeach
                    @endif
                @endforeach
            @endforeach
            
        </tbody>
        </table>
        </div>
        </div>
        </div>
        </div>

 
        
    </div>