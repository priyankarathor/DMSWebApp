<div>
    <div class="container mt-3">
        <div class="row">
        <div class="card">
        <div class="card-header">

            <div class="row">
            <div class="col-md-8">
                <h4 class="card-title">Retailer List</h4>
            </div>
            <div class="col-md-4  text-end">
                <a href="{{route('retailerpage')}}"><button class="btn btn-primary" style="background-color: #0f172a; font-size:17px;">Add Retailer</button></a>   
            </div>
            </div>
        </div>

        <div class="card-body">
        <div class="table-responsive">
        <table class="table mb-0">
        <thead class="thead-light">
        <tr>
        <th>#</th>
        <th>Name</th>
        <th>Email</th>
        <th>Access</th>
        </tr>
        </thead>
        <tbody>
            @foreach ($tab as $item)
            <tr>
                <th scope="row">{{$item->id}}</th>
                <td>{{$item->retailername}}</td>
                <td>{{$item->email}}</td>
                <td><span class="badge badge-boxed  badge-outline-success">Business</span></td>
                </tr>
            @endforeach
        </tbody>
        </table><!--end /table-->
        </div><!--end /tableresponsive-->
        </div><!--end card-body-->
        </div>
        </div>
    </div>