<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Invoice</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</head>
<body class="border border-2 m-5">
    <header>
        <div class="container-fluid p-4 border-bottom border-3 border-dark">
            <div class="row">
                <div class="col-6">
                    <img src="../Eshana/assets/images/logo-invoice.jpg" class="img-fluid ps-5" style="height:100px;width:350px">
                </div>
                <div class="col-6 ps-3">
                    <ul class="fs-6">
                        <li>
                            Phone:+455 6546 544 58
                        </li>
                        <li>
                            Email:info@bizzgrow@company.email.com
                        </li>
                        <li>
                            S4868 avenue road , John street , House#456 , Road#46 New York ny-5689
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </header>

    <section>
        <div class="container-fluid p-4">
            <div class="row pb-5">
                <div class="col-6 ps-5">
                    <h6><u>INVOICE </u> TO</h6>
                    <h3>Michale Johnson</h3>
                    <span>Manager,Company Name INC.</span>
                    <br><br>
                    <span>
                        Ph : +455 6546 544 58
                    </span><br>
                    <span>
                        Em : info@bizzgrow@company.email.com
                    </span>
                </div>
                <div class="col-6">
                    <h1 class="display-1" style="font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif">INVOICE</h1>
                    <ul type="square">
                        <li>
                            Account No : 5446877654654
                        </li>
                        <li>
                            Invoice Date : Dec 28,2016
                        </li>
                    </ul>
                </div>
            </div>
            <div class="row py-4">
                <div class="col-12">
                    <table class="table">
                        <thead>
                          <tr>
                            <td scope="col" class="col-6 text-white fs-5 ps-5 py-3 pt-0 pe-0" style="background-color:rgb(116, 201, 50)">Item Description</td>
                            <td scope="col" class="text-white fs-5 ps-5 py-3 pe-0 border-right border-white border-2" style="background-color:rgb(7, 45, 93)">Unit Price</td>
                            <td scope="col" class="text-white fs-5 ps-5 py-3 pe-0 border-right border-white border-2" style="background-color:rgb(7, 45, 93)">Qnt</td>
                            <td scope="col" class="text-white fs-5 ps-5 py-3 pe-0 border-right border-white border-2" style="background-color:rgb(7, 45, 93)">Total</td>
                            <td scope="col" class="text-white fs-5 ps-5 py-3 pe-0 " style="background-color:rgb(7, 45, 93)"></td>
                          </tr>
                        </thead>
                        <tbody>
                          <tr>
                            <td scope="row" class="ps-5 pt-3 fs-5"><b>Web Design</b>
                                <p class="fs-6">
                                    This is the first phase of business website design
                                </p>
                            </td>
                            <td class="ps-5 pt-4" scope="row" style="background-color:rgb(241, 241, 241)">$650.00</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">8</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$5200.00</td>
                            <td class="ps-5" style="background-color:rgb(241, 241, 241)"></td>
                          </tr>
                          <tr>
                            <td scope="row" class="ps-5 fs-5  pt-3"><b>Graphic Design</b>
                                <p class="fs-6">
                                    This is the first phase of business website design
                                </p>
                            </td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$385.00</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">3</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$1155.00</td>
                            <td class="ps-5" style="background-color:rgb(241, 241, 241)"></td>
                          </tr>
                          <tr>
                            <td scope="row" class="ps-5 fs-5  pt-3"><b>Brochure Design</b>
                                <p class="fs-6">
                                    This is the first phase of business website design
                                </p>
                            </td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$420.00</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">4</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$1680.00</td>
                            <td class="ps-5" style="background-color:rgb(241, 241, 241)"></td>
                          </tr>
                          <tr>
                            <td scope="row" class="ps-5 fs-5  pt-3"><b>Brochure Design</b>
                                <p class="fs-6">
                                    This is the first phase of business website design
                                </p>
                            </td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$150.00</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">1</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$150.00</td>
                            <td class="ps-5" style="background-color:rgb(241, 241, 241)"></td>
                          </tr>
                          <tr>
                            <td scope="row" class="ps-5 fs-5  pt-3"><b>Print Design</b>
                                <p class="fs-6">
                                    This is the first phase of business website design
                                </p>
                            </td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$300.00</td>
                            <td class="ps-5 pt-4 " style="background-color:rgb(241, 241, 241)">12</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)">$3600.00</td>
                            <td class="ps-5 pt-4" style="background-color:rgb(241, 241, 241)"></td>
                          </tr>
                          <tr class="border-bottom border-success" style="border-bottom-width: 20px;">
                            <td class="ps-5 py-3" rowspan="4">
                                <span><b>TOTAL DUE</b></span>
                                <h2 style="color:rgb(116, 201, 50)">USD: $12875.00</h2>
                            </td>
                          </tr>
                          <tr class="text-center">
                            <td colspan="4" style="background-color:rgb(196, 192, 192)">
                                <span >Sub Total</span>
                                <span>:</span>
                                <span>
                                    $11785.00
                                </span>
                            </td> 
                        </tr>
                        <tr class="text-center">
                            <td colspan="4" style="background-color:rgb(196, 192, 192)">
                                <span>Tax vat 15%</span>
                                <span>:</span>
                                <span>
                                    $1767.00
                                </span>
                          </td>
                        </tr>
                        <tr class="text-center">
                            <td colspan="4" style="background-color:rgb(196, 192, 192)">
                                <span>Discount 5%</span>
                                <span>:</span>
                                <span>
                                    $677.00
                                </span>
                            </td>
                        </tr>
                        <tr>
                            <td style="border:none" class="pt-3">
                                <h4 class="text-info ps-5">Thank you for your business</h4>
                                <h6 class="ps-5">Terms & conditions</h6>
                            </td>
                            <td colspan="4" class="text-center pt-3" style="background-color:rgb(7, 45, 93);color:rgb(116, 201, 50)">
                                <span class="fs-3 fw-bold">GRAND TOTAL</span>
                                <span class="fs-3 fw-bold"> : </span>
                                <span class="fs-3 fw-bold">
                                    $1275.00
                                </span>
                            </td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container-fluid p-4 border-top border-dark border-2">
            <div class="row">
                <div class="col-4 pt-3">
                    <h3><u>PAYMENT METHODS</u></h3>
                    <span class="fw-bold">Paypal :</span>
                    <span>info@bizzgrow@company.email.com</span><br>
                    <span class="fw-bold">Payment :</span>
                    <span>Visa Master card we accept cheque</span>
                </div>
                <div class="col-4">

                </div>
                <div class="col-4">
                    <u class="fs-3"><i>Mic Johnson</i></u>
                    <h3>Michale Johnson</h3>
                    <span>
                        Managing Director , Company Name INC.
                    </span>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>