<div>
    <div class="page-wrapper">

            <div class="container-fluid mt-4" style="padding: 60px;" >
                <div class="row">
                    <div class="col-lg-12 mx-auto">
                        <div class="card">
                            <div class="card-body invoice-head">
                                <div class="row">
                                    <meta charset="UTF-8">
                                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                                    <title>Invoice</title>
                                    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
                                        rel="stylesheet"
                                        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
                                        crossorigin="anonymous">
                                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
                                        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
                                    </script>
                                    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
                                        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous">
                                    </script>
                                    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js"
                                        integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous">
                                    </script>

                                    <body class="border border-2 m-5">
                                        <div class="container">
                                            <div class="invoice-box">
                                                <div class="row">

                                                    <header>
                                                        <div class="container p-4 border-bottom border-3 border-dark">

                                                            <div class="row">
                                                                <div class="col-6">
                                                                    <img src="{{ asset('image/vmlogo.png') }}"
                                                                        alt="logo-small"
                                                                        style="width: 50%; height:auto; text-align: center !important;"
                                                                        class="mb-1 mt-1">
                                                                </div>
                                                                <div class="col-6 ps-3">
                                                                    <ul class="fs-6">
                                                                        <li>
                                                                            Phone:+91 9829361615
                                                                        </li>
                                                                        <li>
                                                                            Email:info@vandemileagerlubricant.com
                                                                        </li>
                                                                        <li>
                                                                            <b>GST NO.</b> : 08AHHPC4356M1Z4.
                                                                        </li>
                                                                        <li>
                                                                            Company corporate office Near by TTC
                                                                            Industrial Area (MIDC) North Central Road
                                                                            Navi Mumbai - 400701 Maharashtra
                                                                        </li>
                                                                    </ul>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </header>

                                                    <section>
                                                        <div class="container-fluid p-4">
                                                            <div class="row pb-5">
                                                                <div class="col-6 ps-2">
                                                                    <h6><u>INVOICE </u> TO</h6>
                                                                    <h3>{{ $productdata->companyname }}</h3>

                                                                    <span>
                                                                        Ph : +91{{ $productdata->companycontact }}
                                                                    </span><br>
                                                                    <span>
                                                                        Em : {{ $productdata->companyemail }}
                                                                    </span><br>
                                                                    <span>
                                                                        GST No. : {{ $productdata->gstrate }}
                                                                    </span><br>
                                                                    <span>
                                                                        Udyam Card No. : {{ $productdata->udyamno }}
                                                                    </span>
                                                                </div>
                                                                <div class="col-6">
                                                                    <h5 class="display-5"
                                                                        style="font-family:'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif">
                                                                        GST INVOICE</h5>
                                                                    <span>
                                                                        <b> Invoice No. </b> :
                                                                        {{ $productdata->invoicenum }}
                                                                    </span> ||
                                                                    <span>
                                                                        <b> Date :</b> {{ $productdata->invoicedate }}
                                                                    </span>

                                                                    <h5 class="mt-2"><b>Dispatch Through</b></h5>
                                                                    <span>{{ $productdata->drivercompany }}</span>
                                                                    <br /><br /><span>
                                                                        <b>Contact Person : </b>
                                                                        {{ $productdata->drivername }}
                                                                    </span> ||
                                                                    <span>
                                                                        <b> Vehicle No.
                                                                            :</b>{{ $productdata->vehicleno }}
                                                                    </span><br />
                                                                    <span>
                                                                        <b> Contact No. :</b>
                                                                        91+{{ $productdata->vehicleno }}
                                                                    </span>


                                                                </div>
                                                            </div>
                                                            <div class="row py-4">
                                                                <div class="col-12">
                                                                    <table class="table">
                                                                        <thead>
                                                                            <tr>
                                                                                <td scope="col"
                                                                                    class="col-1 text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    Sr No.</td>

                                                                                <td scope="col"
                                                                                    class="col-4 text-white fs-5 ps-2 py-3 pt-0 pe-0"
                                                                                    style="background-color:rgb(116, 201, 50)">
                                                                                    Item Description</td>

                                                                                <td scope="col"
                                                                                    class="text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    HSN</td>
                                                                                <td scope="col"
                                                                                    class="text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    GST RATE%</td>
                                                                                <td scope="col"
                                                                                    class="text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    QNTY</td>
                                                                                <td scope="col"
                                                                                    class="text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    RATES</td>
                                                                                <td scope="col"
                                                                                    class="text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    BOX / BKT</td>
                                                                                <td scope="col"
                                                                                    class="text-white fs-5 ps-2 py-3 pe-0 border-right border-white border-2"
                                                                                    style="background-color:rgb(7, 45, 93)">
                                                                                    Total</td>
                                                                            </tr>
                                                                        </thead>
                                                                        <tbody>
                                                                            @php
                                                                                // Check if productdata contains values before exploding
                                                                                $productNames = $productdata->description
                                                                                    ? explode(
                                                                                        ',',
                                                                                        $productdata->description,
                                                                                    )
                                                                                    : [];
                                                                                $hsncode = $productdata->hsncode
                                                                                    ? explode(
                                                                                        ',',
                                                                                        $productdata->hsncode,
                                                                                    )
                                                                                    : [];
                                                                                $Productqty = $productdata->actualqty
                                                                                    ? explode(
                                                                                        ',',
                                                                                        $productdata->actualqty,
                                                                                    )
                                                                                    : [];
                                                                                $amounts = $productdata->amount
                                                                                    ? explode(',', $productdata->amount)
                                                                                    : [];
                                                                                $productBulks = $productdata->qty
                                                                                    ? explode(',', $productdata->qty)
                                                                                    : [];
                                                                                $totalAmounts = $productdata->totalamount
                                                                                    ? explode(
                                                                                        ',',
                                                                                        $productdata->totalamount,
                                                                                    )
                                                                                    : [];
                                                                            @endphp

                                                                            @foreach ($productNames as $index => $productName)
                                                                                <tr>

                                                                                    <td>{{ $index + 1 }}</td>
                                                                                    <td scope="row"
                                                                                        class="ps-2 pt-3 fs-5">
                                                                                        <b>{{ $productName }}</b></td>
                                                                                    <td class="ps-2 pt-4" scope="row"
                                                                                        style="background-color:rgb(241, 241, 241)">
                                                                                        {{ $hsncode[$index] ?? '' }}
                                                                                    </td>
                                                                                    <td>18 %</td>
                                                                                    <td class="ps-2 pt-4" scope="row"
                                                                                        style="background-color:rgb(241, 241, 241)">
                                                                                        {{ $Productqty[$index] ?? '' }}
                                                                                    </td>
                                                                                    <td class="ps-2 pt-4"
                                                                                        style="background-color:rgb(241, 241, 241)">
                                                                                        {{ $totalAmounts[$index] ?? '' }}
                                                                                    </td>

                                                                                    <td class="ps-2 pt-4"
                                                                                        style="background-color:rgb(241, 241, 241)">
                                                                                        {{ $productBulks[$index] ?? '' }}
                                                                                    </td>
                                                                                    <td class="ps-2 pt-4" scope="row"
                                                                                        style="background-color:rgb(241, 241, 241)">
                                                                                        {{ $amounts[$index] ?? '' }}
                                                                                    </td>
                                                                                </tr>
                                                                            @endforeach



                                                                            @php
                                                                                // Explode the comma-separated totalamount values into an array
                                                                                $totalAmountsArray = explode(
                                                                                    ',',
                                                                                    $productdata->amount,
                                                                                );

                                                                                // Calculate the sum of the totalamount array
                                                                                $totalDue = array_sum(
                                                                                    $totalAmountsArray,
                                                                                );
                                                                            @endphp
                                                                            @php
                                                                                // Explode the comma-separated totalamount, cgst, sgst, and igst values into arrays
                                                                                $totalAmountsArray = explode(
                                                                                    ',',
                                                                                    $productdata->amount,
                                                                                );
                                                                                $cgstArray = explode(
                                                                                    ',',
                                                                                    $productdata->cgst,
                                                                                );
                                                                                $sgstArray = explode(
                                                                                    ',',
                                                                                    $productdata->sgst,
                                                                                );
                                                                                $igstArray = explode(
                                                                                    ',',
                                                                                    $productdata->igst,
                                                                                );

                                                                                // Calculate the sum of totalamount, cgst, sgst, and igst arrays
                                                                                $totalDue = array_sum(
                                                                                    $totalAmountsArray,
                                                                                );
                                                                                $totalCgst = array_sum($cgstArray);
                                                                                $totalSgst = array_sum($sgstArray);
                                                                                $totalIgst = array_sum($igstArray);

                                                                                // Calculate the Grand Total by adding totalDue + cgst + sgst + igst
                                                                                $grandTotal =
                                                                                    $totalCgst +
                                                                                    $totalSgst +
                                                                                    $totalIgst;
                                                                                $grandTotales =
                                                                                    $totalDue +
                                                                                    $totalCgst +
                                                                                    $totalSgst +
                                                                                    $totalIgst;
                                                                            @endphp

                                                                            <tr class="border-bottom border-success"
                                                                                style="border-bottom-width: 20px;">
                                                                                <td class=" py-3" rowspan="10"
                                                                                    colspan="2">
                                                                                    <span><b>Amount In Words</b></span>
                                                                                    <h2 style="color:rgb(116, 201, 50)"
                                                                                        id="amountInWords"></h2>
                                                                                    <!-- Display the total sum -->
                                                                                </td><br />
                                                                                <script>
                                                                                    function convertToWords(num) {
                                                                                        const ones = ["", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven",
                                                                                            "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
                                                                                        ];
                                                                                        const tens = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];

                                                                                        function twoDigitWord(n) {
                                                                                            if (n < 20) {
                                                                                                return ones[n];
                                                                                            } else {
                                                                                                return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? " " + ones[n % 10] : "");
                                                                                            }
                                                                                        }

                                                                                        function threeDigitWord(n) {
                                                                                            const hundredPart = Math.floor(n / 100);
                                                                                            const remainder = n % 100;
                                                                                            const hundredText = hundredPart > 0 ? ones[hundredPart] + " hundred" : "";
                                                                                            const remainderText = remainder > 0 ? " " + twoDigitWord(remainder) : "";
                                                                                            return hundredText + remainderText;
                                                                                        }

                                                                                        function numToWords(n) {
                                                                                            if (n === 0) return "zero";

                                                                                            let crore = Math.floor(n / 10000000);
                                                                                            n %= 10000000;
                                                                                            let lakh = Math.floor(n / 100000);
                                                                                            n %= 100000;
                                                                                            let thousand = Math.floor(n / 1000);
                                                                                            n %= 1000;
                                                                                            let hundred = n;

                                                                                            let result = "";

                                                                                            if (crore > 0) result += `${twoDigitWord(crore)} crore `;
                                                                                            if (lakh > 0) result += `${twoDigitWord(lakh)} lakh `;
                                                                                            if (thousand > 0) result += `${twoDigitWord(thousand)} thousand `;
                                                                                            if (hundred > 0) result += threeDigitWord(hundred);

                                                                                            return result.trim() + " only";
                                                                                        }

                                                                                        return numToWords(Math.floor(num));
                                                                                    }

                                                                                    document.addEventListener("DOMContentLoaded", function() {
                                                                                        const totalAmount = {{ number_format($totalDue * 0.18, 2) + $totalDue }};
                                                                                        const amountInWords = convertToWords(parseFloat(totalAmount));
                                                                                        document.getElementById("amountInWords").textContent = amountInWords.charAt(0).toUpperCase() +
                                                                                            amountInWords.slice(1);
                                                                                    });
                                                                                </script>
                                                                            </tr>

                                                                            <tr class="text-center">
                                                                                <td colspan="6"
                                                                                    style="background-color:rgb(196, 192, 192)">
                                                                                    <span>Total Amount</span>:
                                                                                    <span>{{ $totalDue }}</span>
                                                                                </td>
                                                                            </tr>

                                                                            <tr class="text-center">
                                                                                <td colspan="6"
                                                                                    style="background-color:rgb(196, 192, 192)">
                                                                                    <span>CGST (9%)</span>:
                                                                                    <span>{{ number_format($totalDue * 0.09, 2) }}</span>
                                                                                </td>
                                                                            </tr>

                                                                            <tr class="text-center">
                                                                                <td colspan="6"
                                                                                    style="background-color:rgb(196, 192, 192)">
                                                                                    <span>SGST (9%)</span>:
                                                                                    <span>{{ number_format($totalDue * 0.09, 2) }}</span>
                                                                                </td>
                                                                            </tr>

                                                                            <tr class="text-center">
                                                                                <td colspan="6"
                                                                                    style="background-color:rgb(196, 192, 192)">
                                                                                    <span>IGST (18%)</span>:
                                                                                    <span>{{ number_format($totalDue * 0.18, 2) }}</span>
                                                                                </td>
                                                                            </tr>

                                                                            {{-- <tr class="text-center">
                                <td colspan="6" style="background-color:rgb(196, 192, 192)">
                                    <span><b>Total GST Amount</b></span>:
                                    <span><b>{{ number_format(($totalDue * 0.09 * 2) + ($totalDue * 0.18), 2) }}</b></span>
                                </td>
                            </tr> --}}

                                                                            @php
                                                                                $roundedTotal = round($grandTotal); // Calculate the rounded value of the total amount
                                                                                $roundOffValue =
                                                                                    $grandTotal - $roundedTotal; // Calculate the round off value
                                                                                $grandTotalWithRoundOff = $roundedTotal; // Use the rounded total in Grand Total
                                                                            @endphp
                                                                            <tr class="text-center">
                                                                                <td colspan="6"
                                                                                    style="background-color:rgb(196, 192, 192)">
                                                                                    <span>Rount Off</span>
                                                                                    <span>:</span>
                                                                                    <span>
                                                                                        {{ number_format(fmod(round($totalDue * 0.18 + $totalDue, 2), 1), 2) }}


                                                                                    </span>
                                                                                </td>
                                                                            </tr>
                                                                            <tr class="text-center">
                                                                                <td colspan="6"
                                                                                    style="background-color:rgb(196, 192, 192)">
                                                                                    <span>Grand Total</span>
                                                                                    <span>:</span>
                                                                                    <span>

                                                                                        {{ floor($totalDue * 0.18 + $totalDue) }}


                                                                                    </span>
                                                                                </td>
                                                                            </tr>

                                                                        </tbody>
                                                                    </table>
                                                                    <table style="width: 100%">
                                                                        <tr>
                                                                            <td style="border:none" class="pt-3"
                                                                                colspan="5">
                                                                                <h4 class="text-info ps-2">Thank you
                                                                                    for your business</h4>
                                                                                <h6 class="ps-2">Terms & conditions
                                                                                </h6>
                                                                            </td>
                                                                            <td colspan="9"
                                                                                class="text-center pt-3"
                                                                                style="background-color:rgb(7, 45, 93);color:rgb(116, 201, 50)">
                                                                                <span class="fs-3 fw-bold">GRAND
                                                                                    TOTAL</span>
                                                                                <span class="fs-3 fw-bold"> : </span>
                                                                                <span class="fs-3 fw-bold">
                                                                                    {{ $grandTotales }}
                                                                                </span>
                                                                            </td>
                                                                        </tr>
                                                                    </table>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </section>

                                                    <footer>
                                                        <div
                                                            class="container-fluid p-4 border-top border-dark border-2">
                                                            <div class="row">
                                                                <div class="col-4 pt-3">
                                                                    <h3><u>PAYMENT METHODS</u></h3>
                                                                    <span class="fw-bold">Paypal :</span>
                                                                    <span>info@bizzgrow@company.email.com</span><br>
                                                                    <span class="fw-bold">Payment :</span>
                                                                    <span>Visa Master card we accept cheque</span>
                                                                </div>
                                                                <div class="col-4">

                                                                </div>
                                                                <div class="col-4">
                                                                    <u class="fs-3"><i>Mic Johnson</i></u>
                                                                    <h3>Michale Johnson</h3>
                                                                    <span>
                                                                        Managing Director , Company Name INC.
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </footer>


                                                </div>

                                            </div>
                                            <div class="container">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <button id="download-btn"
                                                            class="btn btn-outline-success mt-5 mb-5"
                                                            style="float:right;">Download PDF</button>
                                                    </div>
                                                </div>
                                            </div>

                                            <script>
                                                document.getElementById("download-btn").addEventListener("click", function() {
                                                    var element = document.querySelector(".invoice-box");
                                                    html2pdf(element, {
                                                        margin: 10,
                                                        filename: 'Concentics Pvt Ltd.pdf',
                                                        image: {
                                                            type: 'jpeg',
                                                            quality: 0.98
                                                        },
                                                        html2canvas: {
                                                            scale: 2
                                                        },
                                                        jsPDF: {
                                                            unit: 'mm',
                                                            format: 'a4',
                                                            orientation: 'portrait'
                                                        }
                                                    });
                                                });
                                            </script>
                                            <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
                                    </body>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

