<div>
    <div class="container">
        <div class="row">
            <form id="form-validation-2" class="form " action="{{route('retailerinsert')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="col-lg-12 mt-2">
                    <h4 class="card-title mt-5 mb-3" style="color:#4a6ed8; font-size:30px;">Retailer Details</h4>

                    <div id="amount-rows">
                        <div class="row amount-row">
                            <div class="col-md-12">
                         <div class="card">
                        <div class="card-header">
                        </div><!--end card-header-->
                       
                        <div class="card-body">
                            <div class="row">
                                <div class="mb-2 col-md-6">
                                    <label for="username" class="mb-2">Retailer Name </label>
                                    <input class="form-control" type="text" id="retailername" name="retailername[]">
                                </div>
                                <div class="mb-2 col-md-6">
                                    <label for="username" class="mb-2">Contact NO.</label>
                                    <input class="form-control" type="text" id="contactno" name="contactno[]">
                                </div>

                                <div class="mb-2 col-md-6">
                                    <label for="username" class="mb-2">Email Address</label>
                                    <input class="form-control" type="text" id="email" name="email[]">
                                </div>

                                <div class="mb-2 col-md-6">
                                    <label for="email" class="mb-2">Address</label>
                                    <input class="form-control" type="text" id="address" name="address[]">
                                </div>
                                <div class="mb-2 col-md-6">
                                    <label for="email" class="mb-2">Product</label>
                                    <input class="form-control" type="text" id="product" name="product[]">
                                </div>
                                <div class="mb-2 col-md-6">
                                    <label for="email" class="mb-2">Stock Quantity</label>
                                    <input class="form-control" type="text" id="quantity" name="quantity[]">
                                </div>
                                <div class="mb-2 col-md-6">
                                    <label for="email" class="mb-2">Region</label>
                                    <input class="form-control" type="text" id="region" name="region[]">
                                </div>
                                <div class="mb-2 col-md-6">
                                    <label for="email" class="mb-2">Upload Image</label>
                                    <input class="form-control" type="file" name="file[]" multiple>
                                </div>
                                
                                <div class="col-md-12 mb-4 mt-3">
                                    <button type="button" class="btn btn-danger remove-row">Remove</button>
                                </div>
                            </div>
 
 
                        </div><!--end card-body-->
                            </div>
                            </div>
                            
                            
                            
                    </div><!--end card-->
                </div> <!-- end col -->
 
                <div class="card">
                    <div class="card-body"> <button type="button" style="background-color: #0f172a; color:#fff; font-size:18px;  border-radius:10px;" class="btn btn-primary" id="add-row">Add Row</button>
                        <input type="submit" style="background-color: #0f172a; color:#fff; font-size:18px;  border-radius:10px;" class="btn btn-primary" value="Submit" />
                    </div>
                </div>
            </form><!--end form-->
            
           
        </div>
 
 
        
        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const amountRowsContainer = document.getElementById('amount-rows');
                const addRowButton = document.getElementById('add-row');

                // Function to clone a row
                function cloneRow(row) {
                    const newRow = row.cloneNode(true);
                    const inputs = newRow.querySelectorAll('input, select, textarea');
                    inputs.forEach(input => input.value = ''); // Clear the values

                    // Make sure the 'Remove' button is visible on all cloned rows
                    const removeButton = newRow.querySelector('.remove-row');
                    if (removeButton) {
                        removeButton.style.display = 'inline-block'; // Show 'Remove' button
                    }

                    return newRow;
                }

                // Add event listener to the 'Add Row' button
                addRowButton.addEventListener('click', () => {
                    const firstRow = amountRowsContainer.querySelector('.amount-row');
                    if (firstRow) {
                        const newRow = cloneRow(firstRow);
                        amountRowsContainer.appendChild(newRow);

                        // Ensure the 'Remove' button is hidden only for the first row
                        const firstRemoveButton = firstRow.querySelector('.remove-row');
                        if (firstRemoveButton) {
                            firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on first row
                        }
                    }
                });

                // Add event delegation to handle 'Remove' button clicks
                amountRowsContainer.addEventListener('click', (event) => {
                    if (event.target.classList.contains('remove-row')) {
                        const row = event.target.closest('.amount-row');
                        if (row && amountRowsContainer.children.length > 1) {
                            row.remove();
                        }
                    }

                    // Ensure the 'Remove' button is hidden for the first row after a row is removed
                    const firstRow = amountRowsContainer.querySelector('.amount-row');
                    if (firstRow) {
                        const firstRemoveButton = firstRow.querySelector('.remove-row');
                        if (firstRemoveButton) {
                            firstRemoveButton.style.display = 'none'; // Always hide 'Remove' button on the first row
                        }
                    }
                });

                // Hide 'Remove' button for the first row on page load
                const firstRemoveButton = amountRowsContainer.querySelector('.amount-row .remove-row');
                if (firstRemoveButton) {
                    firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row initially
                }
            });

        </script>
    </div>
</div>
 
</div>