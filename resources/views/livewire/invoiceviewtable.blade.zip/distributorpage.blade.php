<div>
    <div class="container">
        <div class="row">
            <form id="form-validation-2" class="form " action="{{route('distrinuterinsert')}}" method="post" enctype="multipart/form-data">
                @csrf
                    <div class="row mt-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">User Details</h4>
                            </div>
                            <div class="row">
                            <div class="card-body">
                                <div class="row">
                                    <div class="mb-2 col-md-3">
                                        <label for="dependence" class="mb-2">Select Dependence</label>
                                        <select class="form-control" id="dependence" name="dependence" onchange="filterDistributors()">
                                            <option class="text-center" value="">----Select Dependence----</option>
                                            @foreach ($usercategory as $item)
                                                <option value="{{ $item->id }}">{{ $item->role }}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                    
                                    <div class="mb-2 col-md-3" id="distributorIdDiv">
                                        <label for="assignid" class="mb-2">User ID</label>
                                        <select class="form-control" id="assignid" name="assignid" onchange="updateUsernameAndRegion()">
                                            <option class="text-center" value="">----Select User ID----</option>
                                            @foreach ($hierarchy as $data)
                                                <option value="{{ $data->id }}" data-roleid="{{ $data->roleid }}" data-username="{{ $data->username }}" data-region="{{ $data->region }}">
                                                    {{ $data->registerid }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    
                                    <div class="mb-2 col-md-3" id="usernameDiv">
                                        <label for="username" class="mb-2">Dependence Username</label>
                                        <select class="form-control" id="username" name="username" disabled>
                                            <option value="">----Dependence Username----</option>
                                        </select>
                                    </div>
                                    
                                    <div class="mb-2 col-md-3" id="regionDiv">
                                        <label for="region" class="mb-2">Dependence Region</label>
                                        <select class="form-control" id="region" name="region" disabled>
                                            <option value="">----Dependence Region----</option>
                                        </select>
                                    </div>
                                    
                                    <!-- JavaScript to filter User IDs and update Username/Region based on selected User ID -->
                                    <script>
                                    function filterDistributors() {
                                        var dependenceId = document.getElementById("dependence").value;
                                        var userIdDropdown = document.getElementById("assignid");
                                        var userOptions = userIdDropdown.getElementsByTagName("option");
                                    
                                        // Filter User ID dropdown options based on selected Dependence
                                        for (var i = 0; i < userOptions.length; i++) {
                                            var roleId = userOptions[i].getAttribute("data-roleid");
                                            if (roleId == dependenceId || userOptions[i].value === "") {
                                                userOptions[i].style.display = "";
                                            } else {
                                                userOptions[i].style.display = "none";
                                            }
                                        }
                                    }
                                    
                                    function updateUsernameAndRegion() {
                                        var userIdDropdown = document.getElementById("assignid");
                                        var selectedOption = userIdDropdown.options[userIdDropdown.selectedIndex];
                                    
                                        // Get username and region from the selected User ID
                                        var username = selectedOption.getAttribute("data-username");
                                        var region = selectedOption.getAttribute("data-region");
                                    
                                        // Update and enable the Username dropdown
                                        var usernameDropdown = document.getElementById("username");
                                        usernameDropdown.innerHTML = "<option>" + (username ? username : "----Dependence Username----") + "</option>";
                                        usernameDropdown.disabled = !username;
                                    
                                        // Update and enable the Region dropdown
                                        var regionDropdown = document.getElementById("region");
                                        regionDropdown.innerHTML = "<option>" + (region ? region : "----Dependence Region----") + "</option>";
                                        regionDropdown.disabled = !region;
                                    }
                                    </script>
                                    
                                </div>
                                    </div>
                                    
                                
                                    
                          
                                    <div class="mb-2 col-md-3">
                                        <label for="username" class="mb-2">User Register Id</label>
                                        <input class="form-control" type="text" id="registerid" name="registerid">
                                    </div>

                                    <div class="mb-2 col-md-3">
                                        <label for="username" class="mb-2">User Name </label>
                                        <input class="form-control" type="text" id="username" name="username">
                                    </div>
                                <div class="mb-2 col-md-3">
                                    <label for="username" class="mb-2">Select Role</label>
                                    <select class="form-control" id="dependence" name="dependence">
                                        <option class="text-center" value="">----select Dependence---</option>
                                        @foreach ($usercategory as $item)
                                            <option value="{{ $item->id }}">{{ $item->role }}</option>
                                        @endforeach
                                    </select>
                                </div>
                            
                                <div class="mb-2 col-md-3">
                                    <label for="username" class89="mb-2">Contact NO.</label>
                                    <input class="form-control" type="text" id="contactno" name="contactno">
                                </div>

                                <div class="mb-2 col-md-3">
                                    <label for="email" class="mb-2">Alternative Number</label>
                                    <input class="form-control" type="text" id="alternativenum" name="alternativenum">
                                </div>

                                <div class="mb-2 col-md-3">
                                    <label for="username" class="mb-2">Email Address</label>
                                    <input class="form-control" type="text" id="email" name="email">
                                </div>

                               
                                <div class="mb-2 col-md-3">
                                    <label for="email" class="mb-2">Upload Image</label>
                                    <input class="form-control" type="file" name="file" multiple>
                                </div>
                            </div>
                        </div>
                        </div><!--end card-body-->
                            </div>
                            </div>
                            
                            <div class="row">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">Company Details</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                        <div class="mb-2 col-md-6">
                                            <label for="username" class="mb-2">Firm Name</label>
                                            <input class="form-control" type="text" id="companyname" name="companyname">
                                        </div>

                                        <div class="mb-2 col-md-6">
                                            <label for="email" class="mb-2">Date</label>
                                            <input class="form-control" type="date" id="insertdate" name="insertdate">
                                        </div>

                                       
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">GST Number</label>
                                            <input class="form-control" type="text" id="gstcode" name="gstcode">
                                        </div>
        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">PIN Code</label>
                                            <input class="form-control" type="text" id="pincode" name="pincode">
                                        </div>

                                        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">City</label>
                                            <input class="form-control" type="text" id="city" name="city">
                                        </div>
                                        <div class="mb-2 col-md-3">
                                            <label for="email" class="mb-2">State</label>
                                            <input class="form-control" type="text" id="state" name="state">
                                        </div>
        
                                        <div class="mb-2 col-md-3">
                                            <label for="email" class="mb-2">tehsils</label>
                                            <input class="form-control" type="text" id="tehsils" name="tehsils">
                                        </div>


                                        <div class="mb-2 col-md-3">
                                            <label for="email" class="mb-2">Region</label>
                                            <input class="form-control" type="text" id="region" name="region">
                                        </div>


                                        <div class="mb-2 col-md-3">
                                            <label for="email" class="mb-2">Postal / Zip Code</label>
                                            <input class="form-control" type="text" id="postalcode" name="postalcode">
                                        </div>
        

                                        <div class="mb-2 col-md-12">
                                            <label for="email" class="mb-2">Address</label>
                                            <textarea class="form-control" type="text" id="address" name="address"></textarea>
                                        </div>
                                       
                                        </div>
                                    </div>
                                </div></div>

                <!--start bank details-->
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">Bank Details</h4>
                        </div>
                        
                        <div class="card-body">
                            <div class="row">
                <div class="mb-2 col-md-6">
                    <label for="email" class="mb-2">Bank Name</label>
                    <input class="form-control" type="text" id="bankname" name="bankname">
                </div>

                <div class="mb-2 col-md-6">
                    <label for="email" class="mb-2">Bank Account Number</label>
                    <input class="form-control" type="text" id="accountnumber" name="accountnumber">
                </div>

                <div class="mb-2 col-md-6">
                    <label for="email" class="mb-2">Account IFSC Code</label>
                    <input class="form-control" type="text" id="ifsccode" name="ifsccode">
                </div>

                <div class="mb-2 col-md-3">
                    <label for="email" class="mb-2">Account Holder Name</label>
                    <input class="form-control" type="text" id="holdername" name="holdername">
                </div>

                <div class="mb-2 col-md-3">
                    <label for="email" class="mb-2">Account type</label>
                <select class="form-control" type="text" id="accounttype" name="accounttype">
                    <option value="Current">Current</option>   
                    <option value="Saving">Saving</option>
                       
                    </select>
                </div>
                
                <div class="col-md-12 my-3">
                    <input type="submit" style="font-size:18px;  border-radius:10px;" class="btn btn-success" value="Submit" />
                </div>
                        </div>
                        </div>
                    </div>
                </div>
                <!--end bank details-->

                </div>
            </form><!--end form-->
        </div>

        <script>
           document.addEventListener('DOMContentLoaded', () => {
    const amountRowsContainer = document.getElementById('amount-rows');
    const addRowButton = document.getElementById('add-row');

    // Function to clone a row
    function cloneRow(row) {
        const newRow = row.cloneNode(true);
        const inputs = newRow.querySelectorAll('input, select, textarea');
        inputs.forEach(input => input.value = ''); // Clear the values

        // Show the 'Remove' button on cloned rows
        const removeButton = newRow.querySelector('.remove-row');
        if (removeButton) {
            removeButton.style.display = 'inline-block'; // Make sure the 'Remove' button is visible on new rows
        }

        return newRow;
    }

    // Add event listener to the 'Add Row' button
    addRowButton.addEventListener('click', () => {
        const firstRow = amountRowsContainer.querySelector('.amount-row');
        if (firstRow) {
            const newRow = cloneRow(firstRow);
            amountRowsContainer.appendChild(newRow);

            // Ensure the 'Remove' button is hidden for the first row
            const firstRemoveButton = firstRow.querySelector('.remove-row');
            if (firstRemoveButton) {
                firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row
            }
        }
    });

    // Add event delegation to handle 'Remove' button clicks
    amountRowsContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('remove-row')) {
            const row = event.target.closest('.amount-row');
            if (row && amountRowsContainer.children.length > 1) {
                row.remove();
            }
        }

        // Ensure the 'Remove' button is hidden for the first row after a row is removed
        const firstRow = amountRowsContainer.querySelector('.amount-row');
        if (firstRow) {
            const firstRemoveButton = firstRow.querySelector('.remove-row');
            if (firstRemoveButton) {
                firstRemoveButton.style.display = 'none'; // Always hide 'Remove' button on the first row
            }
        }
    });

    // Hide 'Remove' button for the first row on page load
    const firstRemoveButton = amountRowsContainer.querySelector('.amount-row .remove-row');
    if (firstRemoveButton) {
        firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row initially
    }
    });
        </script>
    </div>
</div>
 
</div>