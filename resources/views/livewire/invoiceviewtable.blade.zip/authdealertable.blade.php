
    <div>
        <div class="container mt-3">
            <div class="row">
                <div class="card">
                    <div class="card-header">
                        <div class="row mt-2">
                            <div class="col-md-6">
                                <span class="card-title">Distributor List</span>&nbsp;&nbsp;
                                <a href="{{route('distributor')}}">
                                    <button class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Add Distributor +</button>
                                </a>
                                <button onclick="exportTableToExcel('myTable', 'InvoicesData')" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Excel</button>
                                <button onclick="downloadPDF()" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">PDF</button>
                            </div>
{{--     
                            <div class="col-md-3">
                                <select class="form-control" id="dependence" name="dependence" onchange="checkDependence()">
                                    <option class="text-center" value="">----select Dependence---</option>
                                    @foreach ($category as $item)
                                        <option value="{{ $item->value }}">{{ $item->value }}</option>
                                    @endforeach
                                </select>
                            </div> --}}
    
                            <div class="col-md-3">
                                <div class="row justify-content-end">
                                    <div class="d-flex align-items-center">
                                        <span for="search" class="form-label me-2">Search:</span>
                                        <input type="text" class="form-control" name="search" id="search" placeholder="Search table data...">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div><!-- end card-header -->
    
                    <!-- Distributors Table -->
                    <table class="table mb-0" id="Distributors">
                        <thead class="thead-light">
                            <tr>
                                <th>Register Number</th>
                                <th>User Name</th>
                                <th>Contact No.</th>
                                <th>Region</th>
                                <th>Role</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($tab as $item)
                                <tr>
                                    <td>{{ $item->registerId }}</td>
                                    <td><a href="{{url('/allhierarchydata/'.$item->id)}}">{{ $item->username }}</a></td>
                                    <td>{{ $item->contactno }}</td>
                                    <td>{{ $item->region }}</td>
                                    <td>{{ $item->role }}</td>
                                    <td>{{ $item->created_at }}</td>
                                   
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
</div>
            </div>
        </div>
    </div>