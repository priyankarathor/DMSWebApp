<div>
    <div class="container mt-3">
        <div class="row">
        <div class="card">
        <div class="card-header">
            <div class="row mt-2">
                <div class="col-md-8">
                <span class="card-title">Order  List</span> &nbsp;&nbsp;

                <button onclick="exportTableToExcel('myTable', 'InvoicesData')" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Excel</button>
                <button onclick="downloadPDF()" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">PDF</button>
             
               <a href="#"> <button  class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">All</button></a>
                 
            </div>

                <div class="col-md-4">
                  <div class="row justify-content-end">
                        <div class=" d-flex align-items-center">
                            <span for="search" class="form-label me-2">Search:</span>
                            <input type="text" class="form-control" name="search" id="search" placeholder="Search table data...">
                    
                    </div>
                </div>
                </div>
            </div>
            </div>
            
        <div class="card-body">
        <div class="table-responsive">
        <table class="table mb-0" id="myTable">
        <thead class="thead-light">
        
        {{-- <th>#</th> --}}
        <th>User Register Id</th>
        <th>User Name</th>
        <th>User Email</th>
        <th>User Contact</th>
        <th>Product status</th>
        <th>Date/Time</th>
        <th>Access</th>
        </tr>
        </thead>
        <tbody>
            @foreach ($tab as $item)
            <tr>
                <th scope="row">{{$item->userregisterid}}</th>
                <td>{{$item->username}}</td>
                <td>{{$item->useremail}}</td>
                <td>{{$item->userphone}}</td>
                <td>Panding</td>
                <td>{{$item->created_at}}</td>
                <td>
                    <a href="{{url('/orderproduct/'.$item->id)}}"> <button class="btn btn-outline-success">Product</button></a>
                 </td> 
               
            </tr>
            @endforeach
        </tbody>
        </table>
        </div>
        </div>
        </div>
        </div>

        <script>   
            function updateStatus(id) {
                var checkbox = document.querySelector('#status' + id + ' input[type="checkbox"]');
                var status = checkbox.checked ? 'Active' : 'Disable';

                fetch('/viewstatus', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': '{{ csrf_token() }}' // Add CSRF token
                    },
                    body: JSON.stringify({ id: id, status: status })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        alert('Status updated to ' + data.status);
                    }
                })
                .catch(error => console.error('Error:', error));
            }
            function deletefun(id){
            let check =  confirm("are you sure to delete this data");
            if(check == true){
                window.location.href='/deleteslide/'+id;
            }else{

            }
            }
            </script>
          <script>
            function exportTableToExcel(tableID, filename = '') {
                var table = document.getElementById(tableID);
                if (!table) {
                    alert("Table not found!");
                    return;
                }
        
                // Create a workbook from the table
                var wb = XLSX.utils.table_to_book(table, { sheet: "Sheet1" });
        
                // Filename handling
                filename = filename ? filename : 'ExcelData';
                
                // Write the workbook to an Excel file
                XLSX.writeFile(wb, filename + ".xlsx");
            }
        </script>
        
    </div>