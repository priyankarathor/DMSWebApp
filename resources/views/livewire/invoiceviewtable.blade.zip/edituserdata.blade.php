<div>
    <div class="container">
        <div class="row">
            <form id="form-validation-2" class="form " action="{{ url('/editdistributer/' . $userdata->id) }}" method="post"
                enctype="multipart/form-data">
                @csrf
                <div class="row mt-3">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">User Details</h4>
                        </div>
                        <div class="row">
                            <div class="card-body">
                                <div class="row">

                                    <!-- Select Dependence Dropdown -->
                                    <div class="mb-2 col-md-3">
                                        <label for="dependence" class="mb-2">Select Dependence</label>
                                        <select class="form-control" id="dependence" name="dependence">
                                            <option class="text-center" value="">----Select User ID----</option>
                                            @foreach ($usercategory as $item)
                                                @php
                                                    // Check if there is a match in hierarchy based on the userdata's assignid
                                                    $isSelected = false;
                                                    foreach ($hierarchy as $data) {
                                                        if ($userdata->assignid == $data->id && $data->roleid == $item->id) {
                                                            $isSelected = true;
                                                            break; // Exit the loop if match is found
                                                        }
                                                    }
                                                @endphp
                                                <option value="{{ $item->id }}" data-roleid="{{ $item->role }}" 
                                                    {{ $isSelected ? 'selected' : '' }}>
                                                    {{ $item->role }}
                                                </option>
                                            @endforeach
                                        </select>
                                        
                                        
                                    </div>

                                    <!-- User ID Dropdown for Distributors -->
                                    <div class="mb-2 col-md-3" id="distributorIdDiv">
                                        <label for="assignid" class="mb-2">User ID</label>
                                        <select class="form-control" id="assignid" name="assignid">
                                            <option class="text-center" value="">---- Select User ID ----</option>
                                            
                                            @foreach ($hierarchy as $data)
                                                @if ($userdata->assignid == $data->id)
                                                    <option value="{{ $data->assignid }}" data-roleid="{{ $data->registerid }}" selected>
                                                        {{ $data->registerid }}
                                                    </option>
                                                @endif
                                            @endforeach 
                                            
                                            <!-- Loop through user category to add other options -->
                                            @foreach ($hierarchy as $item)
                                                <option value="{{ $item->id }}" data-roleid="{{ $item->registerid }}">
                                                    {{ $item->registerid }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                    

                                    <!-- JavaScript to filter User IDs based on selected Dependence -->
                                    <script>
                                        function filterDistributors() {
                                            var dependenceId = document.getElementById("dependence").value;
                                            var distributorDropdown = document.getElementById("assignid");
                                            var distributorOptions = distributorDropdown.getElementsByTagName("option");

                                            // Reset the User ID dropdown options
                                            for (var i = 0; i < distributorOptions.length; i++) {
                                                var roleId = distributorOptions[i].getAttribute("data-roleid");

                                                // Show options where roleid matches the selected dependence or is the default option
                                                if (roleId == dependenceId || distributorOptions[i].value === "") {
                                                    distributorOptions[i].style.display = "";
                                                } else {
                                                    distributorOptions[i].style.display = "none";
                                                }
                                            }
                                        }
                                    </script>


                                </div>
                            </div>

                           


                            <div class="mb-2 col-md-3">
                                <label for="username" class="mb-2">User Register Id</label>
                                <input class="form-control" type="text" id="registerid" name="registerid"
                                    value="{{ $userdata->registerid }}">
                            </div>

                            <div class="mb-2 col-md-3">
                                <label for="username" class="mb-2">User Name </label>
                                <input class="form-control" type="text" id="username" name="username"
                                    value="{{ $userdata->username }}">
                            </div>
                            <div class="mb-2 col-md-3">
                                <label for="username" class="mb-2">Select Role</label>
                                <select class="form-control" name="roleid">
                                    @foreach ($usercategory as $item)
                                        <option value="{{ $item->id }}" 
                                            @if($item->id == $userdata->roleid) selected @endif>
                                            {{ $item->role }}
                                        </option>
                                    @endforeach
                                </select>
                                
                            </div>

                            <div class="mb-2 col-md-3">
                                <label for="username" class89="mb-2">Contact NO.</label>
                                <input class="form-control" type="text" id="contactno" name="contactno"
                                    value="{{ $userdata->contactno }}">
                            </div>

                            <div class="mb-2 col-md-3">
                                <label for="email" class="mb-2">Alternative Number</label>
                                <input class="form-control" type="text" id="alternativenum" name="alternativenum"
                                    value="{{ $userdata->alternativenum }}">
                            </div>

                            <div class="mb-2 col-md-3">
                                <label for="username" class="mb-2">Email Address</label>
                                <input class="form-control" type="text" id="email" name="email"
                                    value="{{ $userdata->email }}">
                            </div>


                            <div class="mb-2 col-md-3">
                                <label for="email" class="mb-2">Upload Image</label>
                                <input class="form-control" type="file" name="file"
                                    value="{{ $userdata->file }}">
                            </div>
                        </div>  
                    </div>
                </div><!--end card-body-->
        </div>
    

    <div class="row">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">Company Details</h4>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="mb-2 col-md-6">
                        <label for="username" class="mb-2">Farm Name</label>
                        <input class="form-control" type="text" id="companyname" name="companyname"
                            value="{{ $userdata->framname }}">
                    </div>

                    <div class="mb-2 col-md-6">
                        <label for="email" class="mb-2">Date</label>
                        <input class="form-control" type="date" id="insertdate" name="insertdate"
                            value="{{ $userdata->insertdate }}">
                    </div>


                    <div class="mb-2 col-md-4">
                        <label for="email" class="mb-2">GST Number</label>
                        <input class="form-control" type="text" id="gstcode" name="gstcode"
                            value="{{ $userdata->gstcode }}">
                    </div>

                    <div class="mb-2 col-md-4">
                        <label for="email" class="mb-2">PIN Code</label>
                        <input class="form-control" type="text" id="pincode" name="pincode"
                            value="{{ $userdata->pincode }}">
                    </div>


                    <div class="mb-2 col-md-4">
                        <label for="email" class="mb-2">City</label>
                        <input class="form-control" type="text" id="city" name="city"
                            value="{{ $userdata->city }}">
                    </div>
                    <div class="mb-2 col-md-3">
                        <label for="email" class="mb-2">State</label>
                        <input class="form-control" type="text" id="state" name="state"
                            value="{{ $userdata->state }}">
                    </div>

                    <div class="mb-2 col-md-3">
                        <label for="email" class="mb-2">tehsils</label>
                        <input class="form-control" type="text" id="tehsils" name="tehsils"
                            value="{{ $userdata->tehsils }}">
                    </div>


                    <div class="mb-2 col-md-3">
                        <label for="email" class="mb-2">Region</label>
                        <input class="form-control" type="text" id="region" name="region"
                            value="{{ $userdata->region }}">
                    </div>


                    <div class="mb-2 col-md-3">
                        <label for="email" class="mb-2">Postal / Zip Code</label>
                        <input class="form-control" type="text" id="postalcode" name="postalcode"
                            value="{{ $userdata->postalcode }}">
                    </div>


                    <div class="mb-2 col-md-12">
                        <label for="email" class="mb-2">Address</label>
                        <textarea class="form-control" type="text" id="address" name="address" value="{{ $userdata->address }}">{{ $userdata->address }}</textarea>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!--start bank details-->
    <div class="row">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">Bank Details</h4>
            </div>

            <div class="card-body">
                <div class="row">
                    <div class="mb-2 col-md-6">
                        <label for="email" class="mb-2">Bank Name</label>
                        <input class="form-control" type="text" id="bankname" name="bankname"
                            value="{{ $userdata->bankname }}">
                    </div>

                    <div class="mb-2 col-md-6">
                        <label for="email" class="mb-2">Bank Account Number</label>
                        <input class="form-control" type="text" id="accountnumber" name="accountnumber"
                            value="{{ $userdata->accountnum }}">
                    </div>

                    <div class="mb-2 col-md-6">
                        <label for="email" class="mb-2">Account IFSC Code</label>
                        <input class="form-control" type="text" id="ifsccode" name="ifsccode"
                            value="{{ $userdata->ifsccode }}">
                    </div>

                    <div class="mb-2 col-md-3">
                        <label for="email" class="mb-2">Account Holder Name</label>
                        <input class="form-control" type="text" id="holdername" name="holdername"
                            value="{{ $userdata->holdername }}">
                    </div>

                    <div class="mb-2 col-md-3">
                        <label for="email" class="mb-2">Account type</label>
                        <select class="form-control" type="text" id="accounttype" name="accounttype">
                            <option value="Current" value="{{ $userdata->accounttype }}">Current</option>
                            <option value="Saving" value="{{ $userdata->accounttype }}">Saving</option>

                        </select>
                    </div>

                    <div class="col-md-12 my-3">
                        <input type="submit" style="font-size:18px;  border-radius:10px;" class="btn btn-success"
                            value="Submit" />
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--end bank details-->

</div>
</form><!--end form-->
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const amountRowsContainer = document.getElementById('amount-rows');
        const addRowButton = document.getElementById('add-row');

        // Function to clone a row
        function cloneRow(row) {
            const newRow = row.cloneNode(true);
            const inputs = newRow.querySelectorAll('input, select, textarea');
            inputs.forEach(input => input.value = ''); // Clear the values

            // Show the 'Remove' button on cloned rows
            const removeButton = newRow.querySelector('.remove-row');
            if (removeButton) {
                removeButton.style.display =
                'inline-block'; // Make sure the 'Remove' button is visible on new rows
            }

            return newRow;
        }

        // Add event listener to the 'Add Row' button
        addRowButton.addEventListener('click', () => {
            const firstRow = amountRowsContainer.querySelector('.amount-row');
            if (firstRow) {
                const newRow = cloneRow(firstRow);
                amountRowsContainer.appendChild(newRow);

                // Ensure the 'Remove' button is hidden for the first row
                const firstRemoveButton = firstRow.querySelector('.remove-row');
                if (firstRemoveButton) {
                    firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row
                }
            }
        });

        // Add event delegation to handle 'Remove' button clicks
        amountRowsContainer.addEventListener('click', (event) => {
            if (event.target.classList.contains('remove-row')) {
                const row = event.target.closest('.amount-row');
                if (row && amountRowsContainer.children.length > 1) {
                    row.remove();
                }
            }

            // Ensure the 'Remove' button is hidden for the first row after a row is removed
            const firstRow = amountRowsContainer.querySelector('.amount-row');
            if (firstRow) {
                const firstRemoveButton = firstRow.querySelector('.remove-row');
                if (firstRemoveButton) {
                    firstRemoveButton.style.display =
                    'none'; // Always hide 'Remove' button on the first row
                }
            }
        });

        // Hide 'Remove' button for the first row on page load
        const firstRemoveButton = amountRowsContainer.querySelector('.amount-row .remove-row');
        if (firstRemoveButton) {
            firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row initially
        }
    });
</script>
</div>
</div>

</div>
