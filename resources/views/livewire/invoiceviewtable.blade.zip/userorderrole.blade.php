<div>
    <div class="container mt-3">
        <div class="row">
        <div class="card">
        <div class="card-header">
            <div class="row mt-2">
                <div class="col-md-8">
                <span class="card-title">Order  List</span> &nbsp;&nbsp;

                <button onclick="exportTableToExcel('myTable', 'InvoicesData')" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Excel</button>
                <button onclick="downloadPDF()" class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">PDF</button>
             
               <a href="#"> <button  class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">All</button></a>
                 
            </div>

                <div class="col-md-4">
                  <div class="row justify-content-end">
                        <div class=" d-flex align-items-center">
                            <span for="search" class="form-label me-2">Search:</span>
                            <input type="text" class="form-control" name="search" id="search" placeholder="Search table data...">
                    
                    </div>
                </div>
                </div>
            </div>
            </div>
            
        <div class="card-body">
        <div class="table-responsive">
        <table class="table mb-0" id="myTable">
        <thead class="thead-light">
        
       
            <th>User Register Id</th>
            <th>User Name</th>
            <th>User Contact</th>
            <th>Role</th>
            <th>Product Name</th>
            <th>Weight</th>
            <th>Class</th>
            <th>Hsn Code</th>
            <th>Inventery</th>
        </tr>
        </thead>
        <tbody>
            @php
            // Recursive function to fetch the hierarchy of users
            function fetchHierarchy($tab, $parentId) {
                $result = [];
                foreach ($tab as $user) {
                    if ($user->assignid == $parentId) {
                        $result[] = $user;
                        $result = array_merge($result, fetchHierarchy($tab, $user->id));
                    }
                }
                return $result;
            }
            @endphp
            
            @foreach ($users as $usertab)
                @foreach ($tab as $tables)
                
                    @if($usertab->ragisternum == $tables->id)
                        <tr style="display:none;">
                            <td style="display:none;">{{ $tables->registerid }}</td>
                            <td style="display:none;">{{ $tables->username }}</td>
                            <td style="display:none;">{{ $tables->roleid }}</td>
                        </tr>
            
                        @php
                            // Fetch child hierarchy
                            $hierarchy = fetchHierarchy($tab, $tables->id);
                        @endphp
            
                        @foreach ($hierarchy as $child)
                            <tr>
                                <td>{{ $child->registerid }}</td>
                                <td>{{ $child->username }}</td>
                                <td>{{ $child->contactno }}</td>
                                <td>{{ $child->roleid }}</td>
            
                                @php
                                    // Prepare arrays for the product details
                                    $productsDetails = [];
                                @endphp
            
                                @foreach ($junstiontab as $jtrole)
                                    @if ($jtrole->uid == $child->id)
                                        @foreach ($products as $pro)
                                            @if ($pro->id == $jtrole->pid)
                                                @php
                                                    $productsDetails[] = [
                                                        'id' => $pro->id,
                                                        'name' => $pro->productname,
                                                        'weightnum' => $pro->weightnum,
                                                        'weightclass' => $pro->weihgtclass,
                                                        'hsncode' => $pro->hsncode,
                                                        'inventory' => $jtrole->inventery
                                                    ];  
                                                @endphp
                                            @endif
                                        @endforeach
                                    @endif
                                @endforeach
            
                                <td>
                                    <select onchange="updateDetails(this)" class="form-control">
                                        <option value="">Select Product</option>
                                        @foreach ($productsDetails as $product)
                                            <option value="{{ $product['id'] }}"
                                                data-weightnum="{{ $product['weightnum'] }}"
                                                data-weightclass="{{ $product['weightclass'] }}"
                                                data-hsncode="{{ $product['hsncode'] }}"
                                                data-inventory="{{ $product['inventory'] }}">
                                                {{ $product['name'] }}
                                            </option>
                                        @endforeach
                                    </select>
                                </td>
                                <td class="weightnum"></td>
                                <td class="weightclass"></td>
                                <td class="hsncode"></td>
                                <td class="inventory"></td>
                            </tr>
                        @endforeach
                    @endif
                @endforeach
            @endforeach
            
        </tbody>
        
        </div>
        </div>
        </div>
        </div>
<script>
  
function updateDetails(selectElement) {
    const selectedOption = selectElement.options[selectElement.selectedIndex];
    
    // Retrieve data attributes from the selected option
    const weightnum = selectedOption.getAttribute('data-weightnum');
    const weightclass = selectedOption.getAttribute('data-weightclass');
    const hsncode = selectedOption.getAttribute('data-hsncode');
    const inventory = selectedOption.getAttribute('data-inventory');
    
    // Find the corresponding table cells to update
    const row = selectElement.closest('tr');
    row.querySelector('.weightnum').textContent = weightnum;
    row.querySelector('.weightclass').textContent = weightclass;
    row.querySelector('.hsncode').textContent = hsncode;
    row.querySelector('.inventory').textContent = inventory;
}

    </script>
    </div>