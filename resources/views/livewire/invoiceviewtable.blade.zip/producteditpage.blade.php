<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
<script src="https://cdn.quilljs.com/1.3.6/quill.js"></script>
<div class="container">
    <div class="row">
        <form id="form-validation-2" class="form" action="{{url('/productdataedit/'.$productedit->id) }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="col-lg-12 mt-3">
                <h4 class="card-title mt-0 mb-2" style="font-size: 25px; font-family: 'Pacifico' !important; display: inline-block; color:#115e0f; border:1px solid #115e0f; background-color:#fff; border-radius:10px; padding:20px;">
                    Product Details
                </h4>

                    <div class="row" data-index="0">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="mb-2 col-md-4">
                                            <label for="productname" class="mb-2">Product Name</label>
                                            <input class="form-control" type="text" id="productname" name="productname" value="{{$productedit->productname}}">
                                        </div>

                                        <div class="mb-2 col-md-4">
                                            <label for="category" class="mb-2">Product Category</label>
                                            <span style="color:red;">*</span>
                                            <select class="form-control" id="category" name="category">
                                                <option class="text-center">---Select Product category----</option>
                                                @foreach ($productcate as $item)
                                                    <option value="{{ $item->value }}" <?php if($productedit->category == $item->value){echo 'selected';}?> >{{ $item->value }}</option>
                                                @endforeach
                                            </select>
                                        </div>

                                        <div class="mb-2 col-md-4">
                                            <label for="productprice" class="mb-2">Product Price</label>
                                            <input class="form-control" type="text" id="productprice" name="productprice" value="{{$productedit->productprice}}">
                                        </div>

                                        <div class="mb-2 col-md-4">
                                            <label for="productname" class="mb-2">Product Quantity</label>
                                            <input class="form-control" type="text" id="quantity" name="quantity" value="{{$productedit->quantity}}">
                                        </div>

                                        <div class="mb-2 col-md-4">
                                            <label for="productname" class="mb-2"> Weight(GMS) </label>
                                            <input class="form-control" type="text" id="weightnum" name="weightnum" value="{{$productedit->weightnum}}">
                                        </div>
                                       

                                        <div class="mb-2 col-md-4">
                                            <label for="productprice" class="mb-2">Weight Class</label>
                                            <input class="form-control" type="text" id="weightclass" name="weightclass" value="{{$productedit->weihgtclass}}">
                                        </div>


                                        <div class="mb-2 col-md-4">
                                            <label for="productprice" class="mb-2">Product HSN Code</label>
                                            <input class="form-control" type="text" id="hsncode" name="hsncode" value="{{$productedit->hsncode}}">
                                        </div>

                                        <div class="mb-2 col-md-4">
                                            <label for="file" class="mb-2">Product File</label>
                                            <input class="form-control" type="file" name="file" multiple value="{{$productedit->file}}">
                                        </div>
                                    
                                        <div class="mb-2 col-md-4" style="display: none;">
                                            <label for="image" class="mb-2">Product Multiple Image</label>
                                            <input class="form-control" type="file" name="image[]" multiple>
                                        </div>

                                        
                                        <div class="mb-2 col-md-12" style="display: none;">
                                            <label for="productname" class="mb-2">Link</label>
                                            <input class="form-control" type="text" id="link" name="link">
                                        </div>
                                       

                                        <div class="mb-2 col-md-12" style="display: none;">
                                            <label for="productname" class="mb-2">Meta Tag Title</label>
                                            <input class="form-control" type="text" id="metatag" name="metatag">
                                        </div>
                                       
                                        <div class="mb-2 col-md-12" style="display: none;">
                                            <label for="productname" class="mb-2">Action</label>
                                            <input class="form-control" type="text" id="action" name="action" value="1">
                                        </div>

                                        <div class="mb-2 col-md-12" style="display: none;">
                                            <label for="productprice" class="mb-2">Meta Tag Description</label>
                                       <textarea class="form-control" type="text" id="metadescription" name="metadescription"></textarea>
                                        </div>


                                        <div class="mb-2 col-md-12" style="display: none;">
                                            <label for="productprice" class="mb-2">Meta Tag Keywords</label>
                                       <textarea class="form-control" type="text" id="metakeyword" name="metakeyword"></textarea>
                                                                                  
                                        </div>

                                        <div class="col-md-12 mt-2">
                                            <label for="description" class="mb-2">Description</label>
                                            <textarea class="form-control" id="description" name="description" >{{$productedit->description}}</textarea>
                                        </div>
                                        <script>
                                            CKEDITOR.replace('description');
                                            CKEDITOR.replace('description', {
                                            // CKEditor configuration options
                                            height: 100,
                                            toolbar: [
                                             { name: 'basicstyles', items: ['Bold', 'Italic'] },
                                             { name: 'paragraph', items: ['NumberedList', 'BulletedList'] },
                                             { name: 'links', items: ['Link', 'Unlink'] },
                                             { name: 'insert', items: ['Image', 'Table'] }
                                                 ]
                                             });
                                         </script>

                                         <div class="col-md-12 mt-3 text-end">
                                            <input type="submit" style="font-size:18px; border-radius:10px;" class="btn btn-success" value="Submit" />
                                         </div>
                                    </div>
                                </div><!-- end card-body -->
                            </div>
                        </div>
                    </div>

                
            </div>
        </form><!-- end form -->
    </div><!-- end row -->
</div><!-- end container -->




