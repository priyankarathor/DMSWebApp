<div>
    {{-- Care about people's approval and you will be their prisoner. --}}
    <div>
        <div class="container">
            <div class="row">
                <div class="row">
                    <div class="card mt-4">
                    <form action="{{url('/deletedemoedit/'.$demodetail->id)}}" method="POST" style="padding: 20px;">
                    @csrf
                    <div class="row">
                        <div class="mb-3 col-md-6">
                            <label for="exampleInputEmail1" class="form-label">User Name</label>
                            <input type="text" class="form-control" value="{{$demodetail->username}}" id="username" name="username" aria-describedby="emailHelp">
                             </div>
    
                          <div class="mb-3 col-md-6">
                            <label for="exampleInputEmail1" class="form-label">Contact No</label>
                            <input type="conatctno" class="form-control" value="{{$demodetail->conatctno}}" id="contactno" name="conatctno" aria-describedby="emailHelp">
                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                          </div>
    
                        <div class="mb-3 col-md-6">
                          <label for="exampleInputEmail1" class="form-label">Email address</label>
                          <input type="email" class="form-control" id="email" value="{{$demodetail->email}}" name="email" aria-describedby="emailHelp">
                          <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                        </div>
    
                        <div class="mb-3 col-md-6">
                          <label for="exampleInputPassword1" class="form-label">Password</label>
                          <input type="password" class="form-control" value="{{$demodetail->password}}" id="password" name="password">
                        </div> 
    
                        <div class="mb-3 form-check">
                          <input type="checkbox" class="form-check-input" id="exampleCheck1">
                          <label class="form-check-label" for="exampleCheck1">Check me out</label>
                        </div>
                        <div class="col-md-4">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                      </form>
                </div>
                </div>
            </div>
        </div>
</div>
</div>