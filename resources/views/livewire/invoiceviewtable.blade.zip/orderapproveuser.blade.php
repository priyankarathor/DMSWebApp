<div>
    <div class="container mt-3">
        <div class="row">
            <form action="{{url('/orderstatus/'.$orderproduct->id)}}" method="post">

                @csrf
            <div class="card">
                <div class="card-header">
                    <div class="row mt-2">
                       
                        <div class="col-md-8">
                            <span class="card-title">Product List</span> &nbsp;&nbsp;

                            <button onclick="exportTableToExcel('myTable', 'InvoicesData')"
                                class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">Excel</button>
                            <button onclick="downloadPDF()" class="btn btn-outline-success"
                                style="font-size:15px; border-radius:40px;">PDF</button>

                            {{-- <a href="#"> <button  class="btn btn-outline-success" style="font-size:15px; border-radius:40px;">All</button></a> --}}
                            <a > <button
                                    class="btn btn-outline-success"
                                    style="font-size:15px; border-radius:40px;">Approve</button></a>

                        </div>

                        <div class="col-md-4">
                            <div class="row justify-content-end">
                                <div class=" d-flex align-items-center">
                                    <span for="search" class="form-label me-2">Search:</span>
                                    <input type="text" class="form-control" name="search" id="search"
                                        placeholder="Search table data...">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table mb-0" id="myTable">
                            <thead class="thead-light">
                                <tr>
                                    {{-- <th>#</th> --}}
                                    <th>Product Name</th>
                                    <th>Product Quantity</th>
                                    <th>Product Bulk</th>
                                    <th>Product Status</th>
                                    {{-- <th>Access</th> --}}
                                </tr>
                            </thead>
                            <tbody>
                                @php
                                    $orderProductIds = explode(',', $orderproduct->pid);
                                    $productBulkValues = explode(',', $orderproduct->productbulk);
                                    $orderStatuses = explode(',', $orderproduct->orderstatus);
                                @endphp
                            
                                @foreach ($products as $item)
                                    @if(in_array($item->id, $orderProductIds))
                                        @php
                                            // Find the index of the current product ID in the array
                                            $index = array_search($item->id, $orderProductIds);
                                            // Get the corresponding bulk value and order status using the same index
                                            $bulkValue = isset($productBulkValues[$index]) ? $productBulkValues[$index] : 'N/A';
                                            $orderStatus = isset($orderStatuses[$index]) ? $orderStatuses[$index] : 'Pending'; // Default to 'Pending' if not found
                                        @endphp
                                        <tr>
                                            <th scope="row">{{ $item->productname }}</th>
                                            <td>{{ $item->weightnum }}{{ $item->weihgtclass }}</td>
                                            <td>{{ $bulkValue }}</td>
                                            <td>
                                                <select id="orderstatus" name="orderstatus[]" style="width: 100px; padding:5px; border-radius:10px;"
                                                        onchange="checkInventory(this, {{ $bulkValue }}, {{ $item->id }})">
                                                    <option value="Pending" style="color:#000 !important;" {{ $orderStatus == 'Pending' ? 'selected' : '' }}>Pending</option>
                                                    
                                                    {{-- Loop through data and check inventory --}}
                                                    @foreach ($data as $dataItem)
                                                        @if($dataItem->pid == $item->id && $dataItem->inventery >= $bulkValue)
                                                            <option value="Approve" style="color:#000 !important;" {{ $orderStatus == 'Approve' ? 'selected' : '' }}>Approve</option>
                                                        @endif
                                                    @endforeach
                        
                                                    <option value="Cancel" style="color:#000 !important;" {{ $orderStatus == 'Cancel' ? 'selected' : '' }}>Cancel</option>
                                                </select>
                                            </td>
                                        </tr>
                                    @endif
                                @endforeach
                            </tbody>
                        </table>
                        
                        <script>
                        function checkInventory(selectElement, bulkValue, productId) {
                            // Check if the selected option is "Approve"
                            if (selectElement.value === 'Approve') {
                                // Find the inventory for the selected product in the data array
                                let inventoryAvailable = @json($data).some(dataItem => 
                                    dataItem.pid == productId && dataItem.inventery >= bulkValue
                                );
                                
                                if (!inventoryAvailable) {
                                    alert("You don't have enough inventory to approve this order.");
                                    // Revert to the default option if inventory is insufficient
                                    selectElement.value = 'Pending';
                                }
                            }
                        }
                        </script>
                        
                        
                 
                        
                    </div>
                </div>
            </div>
            </form>
        </div>
          </div>