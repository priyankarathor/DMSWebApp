<div>
    <div class="container">
        <div class="row">
            <form id="form-validation-2" class="form" action="{{route('insertuserdata')}}" method="post" enctype="multipart/form-data">
                @csrf
                    <div class="row mt-3">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">User Details</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="mb-2 col-md-4">
                                        <label for="username" class="mb-2">User Name </label>
                                        <input class="form-control" type="text" id="distributername" name="distributername">
                                    </div>
                                <div class="mb-2 col-md-4">
                                    <label for="username" class="mb-2">Select Role</label>
                                    <select class="form-control" type="text" id="role" name="role">
                                        <option class="text-center" value=" ">----select Role---</option>
                                        @foreach ($usercategory as $item)
                                        <option value="{{$item->value}}">{{$item->value}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            
                                <div class="mb-2 col-md-4">
                                    <label for="username" class="mb-2">Contact No.</label>
                                    <input class="form-control" type="text" id="contactno" name="contactno">
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="email" class="mb-2">Alternative Number</label>
                                    <input class="form-control" type="text" id="alternativenum" name="alternativenum">
                                </div>

                                <div class="mb-2 col-md-4">
                                    <label for="username" class="mb-2">Email Address</label>
                                    <input class="form-control" type="text" id="email" name="email">
                                </div>

                               
                                <div class="mb-2 col-md-4">
                                    <label for="email" class="mb-2">Upload Image</label>
                                    <input class="form-control" type="file" name="file" multiple>
                                </div>
                            </div>
 
                        </div><!--end card-body-->
                            </div>
                            </div>
                            
                            <div class="row">
                                <div class="card">
                                    <div class="card-header">
                                        <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">Company Details</h4>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                        <div class="mb-2 col-md-6">
                                            <label for="username" class="mb-2">Company Name</label>
                                            <input class="form-control" type="text" id="companyname" name="companyname">
                                        </div>

                                        <div class="mb-2 col-md-6">
                                            <label for="email" class="mb-2">Date</label>
                                            <input class="form-control" type="date" id="insertdate" name="insertdate">
                                        </div>

        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">GST Code</label>
                                            <input class="form-control" type="text" id="gstcode" name="gstcode">
                                        </div>
        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">PIN Code</label>
                                            <input class="form-control" type="text" id="pincode" name="pincode">
                                        </div>
        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">Region</label>
                                            <input class="form-control" type="text" id="region" name="region">
                                        </div>

                                        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">tehsils</label>
                                            <input class="form-control" type="text" id="region" name="region">
                                        </div>

                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">City</label>
                                            <input class="form-control" type="text" id="city" name="city">
                                        </div>
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">State</label>
                                            <input class="form-control" type="text" id="state" name="state">
                                        </div>

                                        
                                        <div class="mb-2 col-md-4">
                                            <label for="email" class="mb-2">Postal / Zip Code</label>
                                            <input class="form-control" type="text" id="postalcode" name="postalcode">
                                        </div>

                                        <div class="mb-2 col-md-12">
                                            <label for="email" class="mb-2">Address</label>
                                            <textarea class="form-control" type="text" id="address" name="address"></textarea>
                                        </div>
                                       
                                        </div>
                                    </div>
                                </div></div>

                <!--start bank details-->
                <div class="row">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title mt-1 mb-1" style="color:green; font-size:20px;">Bank Details</h4>
                        </div>
                        
                <div class="card-body">
                <div class="row">
                <div class="mb-2 col-md-6">
                    <label for="email" class="mb-2">Bank Name</label>
                    <input class="form-control" type="text" id="bankname" name="bankname">
                </div>

                <div class="mb-2 col-md-6">
                    <label for="email" class="mb-2">Bank Account Number</label>
                    <input class="form-control" type="text" id="accountnumber" name="accountnumber">
                </div>

                <div class="mb-2 col-md-6">
                    <label for="email" class="mb-2">Account IFSC Code</label>
                    <input class="form-control" type="text" id="ifsccode" name="ifsccode">
                </div>

                <div class="mb-2 col-md-3">
                    <label for="email" class="mb-2">Account Holder Name</label>
                    <input class="form-control" type="text" id="holdername" name="holdername">
                </div>

                <div class="mb-2 col-md-3">
                    <label for="email" class="mb-2">Account type</label>
                <select class="form-control" type="text" id="accounttype" name="accounttype">
                        <option>Saving</option>
                        <option>Current</option>
                    </select>
                </div>
                
                <div class="col-md-12 my-3">
                    <input type="submit" style="font-size:18px;  border-radius:10px;" class="btn btn-success" value="Submit" />
                </div>
                        </div>
                        </div>
                    </div>
                </div>
                <!--end bank details-->

                </div>
            </form><!--end form-->
        </div>

        <script>
           document.addEventListener('DOMContentLoaded', () => {
    const amountRowsContainer = document.getElementById('amount-rows');
    const addRowButton = document.getElementById('add-row');

    // Function to clone a row
    function cloneRow(row) {
        const newRow = row.cloneNode(true);
        const inputs = newRow.querySelectorAll('input, select, textarea');
        inputs.forEach(input => input.value = ''); // Clear the values

        // Show the 'Remove' button on cloned rows
        const removeButton = newRow.querySelector('.remove-row');
        if (removeButton) {
            removeButton.style.display = 'inline-block'; // Make sure the 'Remove' button is visible on new rows
        }

        return newRow;
    }

    // Add event listener to the 'Add Row' button
    addRowButton.addEventListener('click', () => {
        const firstRow = amountRowsContainer.querySelector('.amount-row');
        if (firstRow) {
            const newRow = cloneRow(firstRow);
            amountRowsContainer.appendChild(newRow);

            // Ensure the 'Remove' button is hidden for the first row
            const firstRemoveButton = firstRow.querySelector('.remove-row');
            if (firstRemoveButton) {
                firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row
            }
        }
    });

    // Add event delegation to handle 'Remove' button clicks
    amountRowsContainer.addEventListener('click', (event) => {
        if (event.target.classList.contains('remove-row')) {
            const row = event.target.closest('.amount-row');
            if (row && amountRowsContainer.children.length > 1) {
                row.remove();
            }
        }

        // Ensure the 'Remove' button is hidden for the first row after a row is removed
        const firstRow = amountRowsContainer.querySelector('.amount-row');
        if (firstRow) {
            const firstRemoveButton = firstRow.querySelector('.remove-row');
            if (firstRemoveButton) {
                firstRemoveButton.style.display = 'none'; // Always hide 'Remove' button on the first row
            }
        }
    });

    // Hide 'Remove' button for the first row on page load
    const firstRemoveButton = amountRowsContainer.querySelector('.amount-row .remove-row');
    if (firstRemoveButton) {
        firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row initially
    }
    });
        </script>
    </div>
</div>
 
</div>