<div>
    <div class="container">
        <div class="row">
            <form id="form-validation-2" class="form " action="{{route('insertproduct')}}" method="post" enctype="multipart/form-data">
                @csrf
                <div class="col-lg-12 mt-3">
                    <h4 class="card-title mt-5 mb-3" style="color:green; font-size:20px;">Product Purchase</h4>

                    <div id="amount-rows">
                        <div class="row amount-row">
                            <div class="col-md-12">
                         <div class="card">
                        <div class="card-header">
                        </div><!--end card-header-->
                       
                        <div class="card-body">
                            <div class="row">
                                <div class="mb-2 col-md-6">
                                    <label for="username" class="mb-2">Product Name</label>
                                    <select class="form-control" id="ordername" name="ordername">
                                        <option style="text-align: center;" value=" ">--select product--</option>
                                        @foreach ($product as $item)
                                        <option value="{{$item->productname}}">{{$item->productname}}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="mb-2 col-md-6">
                                    <label for="username" class="mb-2">Product Quantity</label>
                                    <input class="form-control" type="text" id="quantity" name="quantity">
                                </div>

                                <div class="mb-2 col-md-6">
                                    <label for="email" class="mb-2">Expected Delivery Date</label>
                                    <input class="form-control" type="date" id="productexpected" name="productexpected">
                                </div>
                              
                               
                                <div class="col-md-12 mb-4 mt-3">
                                    <input type="submit" style="background-color: #0f172a; color:#fff; font-size:18px;  border-radius:10px;" class="btn btn-primary" value="Submit" />
                                </div>
                            </div>
 
 
                        </div><!--end card-body-->
                            </div>
                            </div>
                            
                            
                            
                    </div>
                </div> 
                </div>
            </form><!--end form-->
            
           
        </div>

        <script>
            document.addEventListener('DOMContentLoaded', () => {
                const amountRowsContainer = document.getElementById('amount-rows');
                const addRowButton = document.getElementById('add-row');

                // Function to clone a row
                function cloneRow(row) {
                    const newRow = row.cloneNode(true);
                    const inputs = newRow.querySelectorAll('input, select, textarea');
                    inputs.forEach(input => input.value = ''); // Clear the values

                    // Make sure the 'Remove' button is visible on all cloned rows
                    const removeButton = newRow.querySelector('.remove-row');
                    if (removeButton) {
                        removeButton.style.display = 'inline-block'; // Show 'Remove' button
                    }

                    return newRow;
                }

                // Add event listener to the 'Add Row' button
                addRowButton.addEventListener('click', () => {
                    const firstRow = amountRowsContainer.querySelector('.amount-row');
                    if (firstRow) {
                        const newRow = cloneRow(firstRow);
                        amountRowsContainer.appendChild(newRow);

                        // Ensure the 'Remove' button is hidden only for the first row
                        const firstRemoveButton = firstRow.querySelector('.remove-row');
                        if (firstRemoveButton) {
                            firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on first row
                        }
                    }
                });

                // Add event delegation to handle 'Remove' button clicks
                amountRowsContainer.addEventListener('click', (event) => {
                    if (event.target.classList.contains('remove-row')) {
                        const row = event.target.closest('.amount-row');
                        if (row && amountRowsContainer.children.length > 1) {
                            row.remove();
                        }
                    }

                    // Ensure the 'Remove' button is hidden for the first row after a row is removed
                    const firstRow = amountRowsContainer.querySelector('.amount-row');
                    if (firstRow) {
                        const firstRemoveButton = firstRow.querySelector('.remove-row');
                        if (firstRemoveButton) {
                            firstRemoveButton.style.display = 'none'; // Always hide 'Remove' button on the first row
                        }
                    }
                });

                // Hide 'Remove' button for the first row on page load
                const firstRemoveButton = amountRowsContainer.querySelector('.amount-row .remove-row');
                if (firstRemoveButton) {
                    firstRemoveButton.style.display = 'none'; // Hide 'Remove' button on the first row initially
                }
            });

        </script>
    </div>
</div>
 
</div>