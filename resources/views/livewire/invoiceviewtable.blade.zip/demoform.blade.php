<div>
    {{-- To attain knowledge, add things every day; To attain wisdom, subtract things every day. --}}
    <div class="container">
        <div class="row">
            <div class="row">
                <div class="card mt-4">
                <form action="{{route('demoinsert')}}" method="POST" style="padding: 20px;">
                @csrf
                <div class="row">
                    <div class="mb-3 col-md-6">
                        <label for="exampleInputEmail1" class="form-label">User Name</label>
                        <input type="text" class="form-control" id="username" name="username" aria-describedby="emailHelp">
                         </div>

                      <div class="mb-3 col-md-6">
                        <label for="exampleInputEmail1" class="form-label">Contact No</label>
                        <input type="conatctno" class="form-control" id="contactno" name="contactno" aria-describedby="emailHelp">
                        <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                      </div>

                    <div class="mb-3 col-md-6">
                      <label for="exampleInputEmail1" class="form-label">Email address</label>
                      <input type="email" class="form-control" id="email" name="email" aria-describedby="emailHelp">
                      <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div>
                    </div>

                    <div class="mb-3 col-md-6">
                      <label for="exampleInputPassword1" class="form-label">Password</label>
                      <input type="password" class="form-control" id="password" name="password">
                    </div> 

                    <div class="mb-3 form-check">
                      <input type="checkbox" class="form-check-input" id="exampleCheck1">
                      <label class="form-check-label" for="exampleCheck1">Check me out</label>
                    </div>
                    <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </div>
                  </form>
            </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="card">
            <div class="card-body">
                <table>
                    <tr>
                        <th>id</th>
                        <th>Username</th>
                        <th>Email</th>
                        <th>password</th>
                        <th>Action</th>
                    </tr>
                    <tbody>

                        @foreach ($tab as $item)
                        <tr>
                            <th>{{$item->id}}</th>
                            <th>{{$item->username}}</th>
                            <th>{{$item->email}}</th>
                            <th>{{$item->password}}</th>

                            <th>
                                <button class="btn btn-success"><a href="{{url('/demoedit/'.$item->id)}}">Edit</a></button>
                                <button class="btn btn-danger"><a href="{{url('/deletedemo/'.$item->id)}}">Delete</a></button>
                            </th>
                        </tr>
                        @endforeach
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>